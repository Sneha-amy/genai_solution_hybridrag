import streamlit as st
import pandas as pd
import requests
import plotly.express as px
import plotly.graph_objects as go
from pdf_report import generate_pdf_report
import tempfile


BACKEND_URL = "http://127.0.0.1:8000/analyze"


# -------------------------------------------
# PAGE SETUP
# -------------------------------------------
st.set_page_config(
    page_title="Financial Anomaly Dashboard",
    layout="wide",
    page_icon="📊"
)

st.title("📊 Financial Anomaly Detection Dashboard")
st.caption("Upload → Analyze → Visualize anomalies, trends, materiality & recommendations")

# -------------------------------------------
# FILE UPLOAD
# -------------------------------------------
uploaded_files = st.file_uploader(
    "Upload Excel or PDF files",
    accept_multiple_files=True,
    type=["xlsx", "xls", "pdf"]
)

run_btn = st.button("🚀 Run Analysis")

# -------------------------------------------
# BACKEND CALL
# -------------------------------------------
if run_btn:
    if not uploaded_files:
        st.error("Please upload at least one file.")
        st.stop()

    with st.spinner("Analyzing financial statements..."):

        files = [
            ("files", (uf.name, uf.read(), uf.type))
            for uf in uploaded_files
        ]

        try:
            response = requests.post(BACKEND_URL, files=files)
        except Exception as e:
            st.error(f"Backend not reachable: {e}")
            st.stop()

        if response.status_code != 200:
            st.error(response.text)
            st.stop()

        result = response.json()

    st.success("Analysis Completed ✔")

    # ==========================================================
    # SECTION 1 — RAW NORMALIZED DATA
    # ==========================================================
    st.header("📄 Normalized Financial Data")
    df = pd.DataFrame(result.get("df_normalized", []))
    st.dataframe(df, use_container_width=True)

    st.markdown("---")

    # ==========================================================
    # SECTION 2 — ANOMALIES TABLE
    # ==========================================================
    st.header("🚨 Detected Anomalies")

    anomalies = pd.DataFrame(result.get("combined_anomalies", []))

    if anomalies.empty:
        st.info("No anomalies found.")
    else:
        st.dataframe(anomalies, use_container_width=True)

    st.markdown("---")

    # ==========================================================
    # SECTION 3 — DASHBOARD ANALYTICS
    # ==========================================================
    st.header("📈 Dashboard Visualizations")

    col1, col2 = st.columns(2)

    # -------------------------------------------
    # 📊 Trend Analysis Chart
    # -------------------------------------------
    trend_data = result.get("trend_analysis", [])

    with col1:
        st.subheader("📉 YoY Trend Changes (%)")

        if trend_data:
            trend_df = pd.DataFrame(trend_data)
            fig = px.bar(
                trend_df,
                x="account",
                y="change_pct",
                color="trend_label",
                title="YoY % Change by Account",
                text="change_pct"
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No trend data available.")

    # -------------------------------------------
    # 🔥 Severity Heatmap
    # -------------------------------------------
    severity = pd.DataFrame(result.get("anomaly_scores", []))

    with col2:
        st.subheader("🔥 Severity Heatmap")

        if not severity.empty:
            pivot = severity.pivot_table(
                index="account",
                columns="period",
                values="severity_score",
                aggfunc="mean"
            )
            fig = px.imshow(
                pivot,
                color_continuous_scale="Reds",
                title="Severity Heatmap (0–1 scale)"
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No severity scores available.")

    st.markdown("---")

    # ----------------------------------------------------------
    # SECTION 4 — MATERIALITY VISUALIZATION
    # ----------------------------------------------------------
    st.header("💰 Materiality Scores")

    materiality = pd.DataFrame(result.get("materiality_scores", []))

    if materiality.empty:
        st.info("Materiality data unavailable.")
    else:
        fig = px.bar(
            materiality,
            x="account",
            y="materiality_ratio",
            title="Materiality Ratio by Account",
            color="materiality_flag"
        )
        st.plotly_chart(fig, use_container_width=True)

    st.markdown("---")

    # ----------------------------------------------------------
    # SECTION 5 — EXPLAINABILITY PANELS
    # ----------------------------------------------------------
    st.header("🧠 Explainability")

    explain_tabs = st.tabs(["Rule", "ML", "Narrative"])

    with explain_tabs[0]:
        st.json(result.get("rule_explainability", []))

    with explain_tabs[1]:
        st.json(result.get("ml_explainability", []))

    with explain_tabs[2]:
        st.json(result.get("narrative_explainability", []))

    st.markdown("---")

    # ----------------------------------------------------------
    # SECTION 6 — RECOMMENDATION SYSTEM
    # ----------------------------------------------------------
    st.header("📝 Recommendations")

    recs = result.get("recommendations", [])

    if not recs:
        st.info("No recommendations to display.")
    else:
        for rec in recs:
            st.markdown(f"""
            ### 🔍 {rec.get('account')}
            **Anomaly ID:** {rec.get('anomaly_id')}  
            **Period:** {rec.get('period', 'N/A')}

            **Recommendation:**  
            {rec.get('recommendation')}
            """)
            st.markdown("---")
            
    

st.header("📄 Export Report")

if st.button("Download PDF Report"):
    with st.spinner("Generating PDF..."):

        # Temporary file
        temp_path = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf").name

        generate_pdf_report(temp_path, result)

        with open(temp_path, "rb") as f:
            st.download_button(
                label="📥 Click to Download Report",
                data=f,
                file_name="financial_anomaly_report.pdf",
                mime="application/pdf"
            )

    st.success("PDF generated successfully!")

