
export function formatCurrency(v){ return '₹' + Number(v).toLocaleString(); }
