
export function renderAnalysisCard(container, report){
  container.className = "card";
  container.innerHTML = `
    <h3>Applicant ${report.applicant_id} — <b>${report.decision}</b></h3>
    <p>${report.decision_rationale}</p>
  `;
}
