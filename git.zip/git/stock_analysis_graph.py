from typing import TypedDict, List, Dict, Any, Optional
from langgraph.graph import StateGraph, END
from datetime import datetime
import requests
from bs4 import BeautifulSoup
from IPython.display import Image, display
import logging
import re
import feedparser
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import pandas as pd
import ta
from ta.momentum import RSIIndicator
from ta.trend import MACD
from ta.volatility import BollingerBands
import csv
import os
from angel_one_api import login_angel_one, fetch_stock_data
from TOKEN_MAP import TOKEN_MAP

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# News analysis constants
ET_MARKETS_RSS = "https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms"

# Optional: map tickers to names/aliases for better matching
SYMBOL_ALIASES = {
    "RELIANCE": ["Reliance", "RIL", "Reliance Industries", "Reliance Industries Limited"],
    "TCS": ["TCS", "Tata Consultancy Services", "Tata Consultancy"],
    "INFY": ["Infosys", "INFY", "Infosys Limited"],
    "HDFCBANK": ["HDFC Bank", "HDFC", "Housing Development Finance Corporation"],
    "ICICIBANK": ["ICICI Bank", "ICICI", "Industrial Credit and Investment Corporation"],
    "HINDUNILVR": ["Hindustan Unilever", "HUL", "Hindustan Unilever Limited"],
    "ITC": ["ITC", "Indian Tobacco Company", "ITC Limited"],
    "SBIN": ["State Bank of India", "SBI", "State Bank"],
    "BHARTIARTL": ["Bharti Airtel", "Airtel", "Bharti"],
    "KOTAKBANK": ["Kotak Mahindra Bank", "Kotak Bank", "Kotak"],
    "LT": ["Larsen & Toubro", "L&T", "Larsen and Toubro"],
    "HCLTECH": ["HCL Technologies", "HCL Tech", "HCL"],
    "ASIANPAINT": ["Asian Paints", "Asian Paint"],
    "MARUTI": ["Maruti Suzuki", "Maruti", "Maruti Suzuki India"],
    "AXISBANK": ["Axis Bank", "Axis"],
    "TITAN": ["Titan Company", "Titan"],
    "SUNPHARMA": ["Sun Pharmaceutical", "Sun Pharma", "Sun Pharmaceutical Industries"],
    "ULTRACEMCO": ["UltraTech Cement", "UltraTech"],
    "NESTLEIND": ["Nestle India", "Nestle"],
    "WIPRO": ["Wipro", "Wipro Limited"],
    "TECHM": ["Tech Mahindra", "Tech M"],
    "NTPC": ["NTPC", "National Thermal Power Corporation"],
    "POWERGRID": ["Power Grid Corporation", "PowerGrid", "Power Grid"],
    "BAJFINANCE": ["Bajaj Finance", "Bajaj Finserv"],
    "ONGC": ["Oil and Natural Gas Corporation", "ONGC"],
    "TATASTEEL": ["Tata Steel", "Tata Steel Limited"],
    "JSWSTEEL": ["JSW Steel", "Jindal South West Steel"],
    "COALINDIA": ["Coal India", "Coal India Limited", "CIL"],
    "INDUSINDBK": ["IndusInd Bank", "IndusInd"],
    "BAJAJ-AUTO": ["Bajaj Auto", "Bajaj"],
    "HEROMOTOCO": ["Hero MotoCorp", "Hero Motors", "Hero"],
    "DRREDDY": ["Dr Reddy's Laboratories", "Dr Reddy", "Dr Reddys"],
    "CIPLA": ["Cipla", "Cipla Limited"],
    "EICHERMOT": ["Eicher Motors", "Eicher"],
    "GRASIM": ["Grasim Industries", "Grasim"],
    "BRITANNIA": ["Britannia Industries", "Britannia"],
    "DIVISLAB": ["Divi's Laboratories", "Divis Lab", "Divi Lab"],
    "ADANIPORTS": ["Adani Ports", "Adani Ports and SEZ", "APSEZ"],
    "TATAMOTORS": ["Tata Motors", "Tata Motors Limited"],
    "BPCL": ["Bharat Petroleum", "BPCL", "Bharat Petroleum Corporation"],
    "HINDALCO": ["Hindalco Industries", "Hindalco"],
    "SHREECEM": ["Shree Cement", "Shree Cements"],
    "APOLLOHOSP": ["Apollo Hospitals", "Apollo Hospital", "Apollo"],
    "TATACONSUM": ["Tata Consumer Products", "Tata Consumer"],
    "M&M": ["Mahindra & Mahindra", "Mahindra", "M&M"],
}

_analyzer = SentimentIntensityAnalyzer()


def load_filtered_stocks():
    """Load filtered stocks from CSV file"""
    csv_file = 'filtered_stocks_30_300.csv'
    
    if not os.path.exists(csv_file):
        logger.warning(f"CSV file {csv_file} not found. Run price_filter.py first.")
        # Fallback to TOKEN_MAP with price range assumption
        logger.info("Using fallback: first 100 stocks from TOKEN_MAP")
        return {symbol: token for symbol, token in list(TOKEN_MAP.items())[:100]}
    
    symbol_tokens = {}
    try:
        with open(csv_file, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                symbol_tokens[row['symbol']] = row['token']
        
        logger.info(f"Loaded {len(symbol_tokens)} filtered stocks from {csv_file}")
        return symbol_tokens
        
    except Exception as e:
        logger.error(f"Error reading CSV file: {e}")
        # Fallback to TOKEN_MAP subset
        return {symbol: token for symbol, token in list(TOKEN_MAP.items())[:50]}


def calculate_technical_indicators(ohlcv_data: List[Dict]) -> Dict[str, Any]:
    """Calculate professional technical indicators from OHLCV data"""
    try:
        # Convert to DataFrame
        df = pd.DataFrame(ohlcv_data)
        df = df.astype(float)
        
        if len(df) < 5:
            return {"error": "Insufficient data for technical analysis"}
        
        # Calculate indicators
        indicators = {}
        
        # RSI (14-period or available data)
        rsi_period = min(14, len(df) - 1)
        if rsi_period >= 2:
            rsi = RSIIndicator(df['close'], window=rsi_period)
            indicators['rsi'] = round(rsi.rsi().iloc[-1], 2)
        else:
            indicators['rsi'] = 50  # Neutral fallback
        
        # MACD
        if len(df) >= 12:
            macd = MACD(df['close'])
            macd_line = macd.macd().iloc[-1]
            macd_signal = macd.macd_signal().iloc[-1]
            indicators['macd_line'] = round(macd_line, 4)
            indicators['macd_signal'] = round(macd_signal, 4)
            indicators['macd'] = "bullish" if macd_line > macd_signal else "bearish"
        else:
            # Simplified MACD for limited data
            sma_fast = df['close'].rolling(3).mean().iloc[-1]
            sma_slow = df['close'].rolling(5).mean().iloc[-1]
            indicators['macd'] = "bullish" if sma_fast > sma_slow else "bearish"
        
        # Bollinger Bands
        if len(df) >= 10:
            bb_period = min(20, len(df))
            bb = BollingerBands(df['close'], window=bb_period)
            bb_upper = bb.bollinger_hband().iloc[-1]
            bb_lower = bb.bollinger_lband().iloc[-1]
            current_price = df['close'].iloc[-1]
            
            bb_position = (current_price - bb_lower) / (bb_upper - bb_lower) * 100
            indicators['bb_position'] = round(bb_position, 2)
        else:
            indicators['bb_position'] = 50  # Neutral
        
        # Volume analysis
        if len(df) >= 5:
            avg_volume = df['volume'].rolling(5).mean().iloc[-2]  # Previous average
            current_volume = df['volume'].iloc[-1]
            indicators['volume_ratio'] = round(current_volume / avg_volume, 2) if avg_volume > 0 else 1
        else:
            indicators['volume_ratio'] = 1
        
        # Price momentum
        if len(df) >= 3:
            price_change_3d = ((df['close'].iloc[-1] - df['close'].iloc[-3]) / df['close'].iloc[-3]) * 100
            indicators['momentum_3d'] = round(price_change_3d, 2)
        else:
            indicators['momentum_3d'] = 0
        
        return indicators
        
    except Exception as e:
        return {"error": f"Technical analysis failed: {str(e)}"}


def _matches_symbol(text: str, symbol: str) -> bool:
    """Match symbol or any alias in text (case-insensitive, word-boundary)."""
    text_l = text.lower()
    candidates = [symbol] + SYMBOL_ALIASES.get(symbol, [])
    for c in candidates:
        c_l = c.lower()
        if re.search(rf"\b{re.escape(c_l)}\b", text_l):
            return True
    return False


def _vader_score(texts: List[str]) -> float:
    """
    Returns an average VADER 'compound' score in [-1, 1].
    """
    if not texts:
        return 0.0

    scores = []
    for t in texts:
        if not t:
            continue
        s = _analyzer.polarity_scores(t)
        scores.append(s["compound"])

    return float(sum(scores) / max(1, len(scores)))


def _label_from_score(score: float) -> str:
    # Common thresholds used with VADER
    if score >= 0.05:
        return "positive"
    if score <= -0.05:
        return "negative"
    return "neutral"


def call_ollama_llm(prompt: str) -> str:
    """Call Ollama API with Llama 3.1 for analysis"""
    try:
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": "llama3.1",
                "prompt": prompt,
                "stream": False
            },
            timeout=30
        )
        if response.status_code == 200:
            return response.json().get("response", "")
        return "LLM analysis unavailable"
    except Exception as e:
        logger.error(f"Ollama API error: {e}")
        return "LLM analysis failed"

# Agent State Definition
class AgentState(TypedDict):
    raw_stocks: List[Dict[str, Any]]
    filtered_stocks: List[str]
    technical_analysis: Dict[str, Dict[str, Any]]
    news_analysis: Dict[str, Dict[str, Any]]
    final_recommendations: List[Dict[str, Any]]
    strong_buy_recommendations: List[Dict[str, Any]]
    timestamp: str
    error: Optional[str]

# Node 1: Fetch and preprocess NSE data
def fetch_nse_data(state: AgentState) -> AgentState:
    try:
        state["timestamp"] = datetime.now().isoformat()
        logger.info("Starting Angel One data fetch...")
        
        # Login to Angel One
        obj = login_angel_one()
        if not obj:
            state["error"] = "Failed to login to Angel One API"
            return state
        
        # Fetch data for symbols that have tokens only
        state["raw_stocks"] = []
        success_count = 0
        fail_count = 0
        
        # Load filtered stocks from CSV (price range 30-300)
        filtered_symbol_tokens = load_filtered_stocks()
        available_symbols = list(filtered_symbol_tokens.keys())
        logger.info(f"Processing {len(available_symbols)} filtered stocks (₹30-₹300 range)")
        
        # Optimized batch processing for 1000+ stocks
        batch_size = 5
        max_workers = 2
        delay = 1.5
        
        batches = [available_symbols[i:i+batch_size] for i in range(0, len(available_symbols), batch_size)]
        start_time = time.time()
        
        for batch_num, batch in enumerate(batches, 1):
            batch_start = time.time()
            logger.info(f"Batch {batch_num}/{len(batches)}: Processing {len(batch)} symbols")
            
            # Process batch in parallel with more workers
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_symbol = {
                    executor.submit(fetch_stock_data, obj, symbol, filtered_symbol_tokens[symbol]): symbol 
                    for symbol in batch
                }
                
                batch_success = 0
                for future in as_completed(future_to_symbol):
                    symbol = future_to_symbol[future]
                    try:
                        stock_data = future.result(timeout=30)  # Add timeout
                        if stock_data:
                            state["raw_stocks"].append(stock_data)
                            success_count += 1
                            batch_success += 1
                        else:
                            raise ValueError(f"Empty response for {symbol}")
                    except Exception as e:
                        logger.error(f"FAILED {symbol} -> {e}")
                        fail_count += 1
                        if fail_count <= 3:
                            logger.error(f"Detailed error for {symbol}: {type(e).__name__}: {str(e)}")
            
            # Progress tracking
            batch_time = time.time() - batch_start
            progress = (batch_num / len(batches)) * 100
            eta = ((time.time() - start_time) / batch_num) * (len(batches) - batch_num)
            success_rate = (batch_success / len(batch)) * 100
            
            logger.info(f"Batch {batch_num} completed in {batch_time:.1f}s | "
                       f"Progress: {progress:.1f}% | ETA: {eta:.0f}s | "
                       f"Batch success: {success_rate:.1f}%")
            
            # Adaptive delay based on success rate
            if success_rate < 70:  # If less than 70% success, slow down
                delay = min(1.0, delay + 0.1)
            elif success_rate > 90:  # If more than 90% success, speed up
                delay = max(0.1, delay - 0.05)
            
            # Delay between batches
            if batch_num < len(batches):
                time.sleep(delay)
        
        logger.info(f"Fetched {success_count} stocks successfully, {fail_count} failed")
        
        # Filtering: volume > 2M, positive change
        state["filtered_stocks"] = [
            stock["symbol"] for stock in state["raw_stocks"]
            if stock["volume"] > 2000000 and stock["change"] > 0
        ]
        
        logger.info(f"Filtered to {len(state['filtered_stocks'])} stocks")
        state["error"] = None
    except Exception as e:
        state["error"] = f"Fetch error: {str(e)}"
        logger.error(f"Fetch error: {e}")
    
    return state

# Node 2: Professional Technical analysis
def technical_analysis(state: AgentState) -> AgentState:
    try:
        state["technical_analysis"] = {}
        
        for symbol in state["filtered_stocks"]:
            stock_data = next(s for s in state["raw_stocks"] if s["symbol"] == symbol)
            
            # Get professional technical indicators
            indicators = calculate_technical_indicators(stock_data["ohlcv_data"])
            
            if "error" in indicators:
                logger.warning(f"Technical analysis failed for {symbol}: {indicators['error']}")
                # Fallback to basic analysis
                change_percent = stock_data["change"]
                indicators = {
                    "rsi": 50 + change_percent,
                    "macd": "bullish" if change_percent > 0 else "bearish",
                    "bb_position": 50,
                    "volume_ratio": 1,
                    "momentum_3d": change_percent
                }
            
            # Calculate composite score using professional indicators
            score = 0
            
            # RSI contribution (0-25 points)
            if indicators['rsi'] > 70:
                score += 10  # Overbought (reduce score)
            elif indicators['rsi'] < 30:
                score += 25  # Oversold (opportunity)
            elif 40 <= indicators['rsi'] <= 60:
                score += 20  # Neutral zone
            else:
                score += 15
            
            # MACD contribution (0-25 points)
            if indicators['macd'] == "bullish":
                score += 25
            elif indicators['macd'] == "bearish":
                score += 5
            else:
                score += 15
            
            # Volume contribution (0-25 points)
            volume_ratio = indicators['volume_ratio']
            if volume_ratio > 1.5:
                score += 25  # High volume
            elif volume_ratio > 1.2:
                score += 20
            elif volume_ratio > 0.8:
                score += 15
            else:
                score += 10  # Low volume
            
            # Momentum contribution (0-25 points)
            momentum = indicators['momentum_3d']
            if momentum > 2:
                score += 25
            elif momentum > 0:
                score += 20
            elif momentum > -2:
                score += 15
            else:
                score += 10
            
            # Generate signal based on multiple factors
            change_percent = stock_data["change"]
            if score >= 80 and change_percent > 1 and indicators['macd'] == "bullish":
                signal = "strong_buy"
            elif score >= 70 and change_percent > 0:
                signal = "buy"
            elif score >= 50:
                signal = "hold"
            else:
                signal = "sell"
            
            state["technical_analysis"][symbol] = {
                "rsi": indicators['rsi'],
                "macd": indicators['macd'],
                "bb_position": indicators['bb_position'],
                "volume_ratio": indicators['volume_ratio'],
                "momentum_3d": indicators['momentum_3d'],
                "score": round(score, 2),
                "signal": signal,
                "change_percent": change_percent
            }
            
    except Exception as e:
        state["error"] = f"Technical analysis error: {str(e)}"
        logger.error(f"Technical analysis error: {e}")
    
    return state

# Node 3: News sentiment analysis
def news_analysis(state: AgentState) -> AgentState:
    try:
        state["news_analysis"] = {}

        feed = feedparser.parse(ET_MARKETS_RSS)
        entries = getattr(feed, "entries", []) or []

        for symbol in state.get("filtered_stocks", []):
            matched_items: List[Dict[str, Any]] = []

            for e in entries:
                title = (e.get("title") or "").strip()
                summary = (e.get("summary") or "").strip()
                link = (e.get("link") or "").strip()
                published = e.get("published") or e.get("updated")

                haystack = f"{title} {summary}"
                if _matches_symbol(haystack, symbol):
                    matched_items.append({
                        "title": title,
                        "summary": summary,
                        "link": link,
                        "published": published,
                    })

            top = matched_items[:5]  # keep a small sample for display/scoring
            headlines = [x["title"] for x in top]
            # Include summary too for a bit more context (optional)
            texts_for_sentiment = [
                (x["title"] + (" - " + x["summary"] if x["summary"] else "")).strip()
                for x in top
            ]

            score = _vader_score(texts_for_sentiment)
            sentiment = _label_from_score(score)

            state["news_analysis"][symbol] = {
                "sentiment": sentiment,
                "sentiment_score": score,   # [-1, 1]
                "headlines": headlines,
                "links": [x["link"] for x in top],
                "news_count": len(matched_items),
                "source": "Economic Times Markets RSS",
                "feed_url": ET_MARKETS_RSS,
            }

    except Exception as e:
        state["error"] = f"News analysis error: {str(e)}"
        logger.error(f"News analysis error: {e}")

    return state

# Node 4: Final analysis and recommendations
def final_analysis(state: AgentState) -> AgentState:
    try:
        state["final_recommendations"] = []
        
        for symbol in state["filtered_stocks"]:
            tech = state["technical_analysis"].get(symbol, {})
            news = state["news_analysis"].get(symbol, {})
            stock_data = next(s for s in state["raw_stocks"] if s["symbol"] == symbol)
            
            # Combine scores
            tech_score = tech.get("score", 0)
            news_score = (news.get("sentiment_score", 0) + 1) * 50  # Convert [-1,1] to [0,100]
            final_score = (tech_score * 0.6) + (news_score * 0.4)
            
            # Prepare data for LLM analysis
            llm_prompt = f"""Analyze this stock for investment decision:
Symbol: {symbol}
Price: ₹{stock_data['price']}
Change: {stock_data['change']}%
Volume: {stock_data['volume']:,}
Technical Score: {tech_score}/100
News Sentiment: {news.get('sentiment', 'neutral')}
News Headlines: {', '.join(news.get('headlines', [])[:2])}

Provide a brief investment recommendation (BUY/HOLD/SELL) with 2-line reasoning."""
            
            llm_analysis = call_ollama_llm(llm_prompt)
            
            # Determine action based on combined analysis
            if "BUY" in llm_analysis.upper() and final_score >= 65:
                action = "STRONG_BUY"
            elif final_score >= 70 or "BUY" in llm_analysis.upper():
                action = "BUY"
            elif final_score >= 50 or "HOLD" in llm_analysis.upper():
                action = "HOLD"
            else:
                action = "SELL"
            
            state["final_recommendations"].append({
                "symbol": symbol,
                "final_score": round(final_score, 2),
                "action": action,
                "technical_signal": tech.get("signal", "N/A"),
                "news_sentiment": news.get("sentiment", "N/A"),
                "llm_analysis": llm_analysis,
                "price": stock_data['price'],
                "change_percent": stock_data['change'],
                "volume": stock_data['volume'],
                "reason": f"Tech: {tech_score}, News: {round(news_score, 2)}"
            })
        
        # Sort by score
        state["final_recommendations"].sort(key=lambda x: x["final_score"], reverse=True)
        
        # Extract strong buy recommendations for frontend
        state["strong_buy_recommendations"] = [
            rec for rec in state["final_recommendations"] 
            if rec["action"] == "STRONG_BUY"
        ]
        
    except Exception as e:
        state["error"] = f"Final analysis error: {str(e)}"
        logger.error(f"Final analysis error: {e}")
    
    return state

def create_stock_analysis_graph():
    workflow = StateGraph(AgentState)
    
    # Add nodes
    workflow.add_node("fetch_nse_data", fetch_nse_data)
    workflow.add_node("technical_analysis", technical_analysis)
    workflow.add_node("news_analysis", news_analysis)
    workflow.add_node("final_analysis", final_analysis)
    
    # Define edges
    workflow.set_entry_point("fetch_nse_data")
    workflow.add_edge("fetch_nse_data", "technical_analysis")
    workflow.add_edge("technical_analysis", "news_analysis")
    workflow.add_edge("news_analysis", "final_analysis")
    workflow.add_edge("final_analysis", END)
    
    return workflow.compile()

# Visualize the graph
def visualize_graph(graph):
    try:
        png_data = graph.get_graph().draw_mermaid_png()
        with open("stock_analysis_graph.png", "wb") as f:
            f.write(png_data)
        print("Graph visualization saved as 'stock_analysis_graph.png'")
    except Exception as e:
        print(f"Visualization error: {e}")
        print("Install: pip install grandalf")

# Run the graph
if __name__ == "__main__":
    graph = create_stock_analysis_graph()
    
    # Visualize
    visualize_graph(graph)
    
    # Initialize state
    initial_state: AgentState = {
        "raw_stocks": [],
        "filtered_stocks": [],
        "technical_analysis": {},
        "news_analysis": {},
        "final_recommendations": [],
        "strong_buy_recommendations": [],
        "timestamp": "",
        "error": None
    }
    
    # Execute
    result = graph.invoke(initial_state)
    
    # Display results
    print("=" * 60)
    print("STOCK ANALYSIS RECOMMENDATIONS")
    print("=" * 60)
    print(f"Timestamp: {result['timestamp']}")
    print(f"Stocks Analyzed: {len(result['filtered_stocks'])}")
    print(f"Strong Buy Recommendations: {len(result['strong_buy_recommendations'])}")
    
    print("\nRecommendations:")
    print("-" * 60)
    
    for rec in result["final_recommendations"]:
        print(f"\n{rec['symbol']}")
        print(f"  Action: {rec['action']}")
        print(f"  Score: {rec['final_score']}")
        print(f"  Technical: {rec['technical_signal']}")
        print(f"  News: {rec['news_sentiment']}")
        print(f"  Reason: {rec['reason']}")
    
    if result.get("error"):
        print(f"\nError: {result['error']}")
