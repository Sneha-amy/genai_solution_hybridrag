import logging
import pandas as pd
from market_data import MarketData
from technical_analysis import TechnicalAnalysis

logger = logging.getLogger(__name__)

class MarketScreener:
    def __init__(self, market_data: MarketData):
        self.market_data = market_data
        # Standard list of Nifty 50 stocks (Subset for demo)
        self.symbols = [
            "RELIANCE", "TCS", "INFY", "HDFCBANK", "ICICIBANK", 
            "SBIN", "BHARTIARTL", "ITC", "KOTAKBANK", "LT",
            "AXISBANK", "HCLTECH", "TATAMOTORS", "MARUTI", "SUNPHARMA",
            "TITAN", "BAJFINANCE", "ULTRACEMCO", "ASIANPAINT", "WIPRO"
        ]

    def scan_market(self, criteria="UNIFIED"):
        """
        Scans values symbols and returns those that match the criteria.
        Criteria: 'UNIFIED' | 'OVERSOLD' | 'VOLUME_SPIKE' | 'MOMENTUM'
        """
        candidates = []
        logger.info(f"Starting Market Scan on {len(self.symbols)} symbols...")
        
        for symbol in self.symbols:
            try:
                # 1. Fetch Fast Data (Last 5 days is enough for indicators)
                df = self.market_data.get_historical_data(symbol, interval="FIFTEEN_MINUTE", days=5)
                
                if df is None or df.empty:
                    continue
                    
                # 2. Add Indicators
                df = TechnicalAnalysis.add_all_indicators(df)
                latest = df.iloc[-1]
                
                match = False
                reason = []
                
                # 3. Apply Filters
                
                # Filter A: Volume Spike (Institutions)
                if latest['RVOL'] > 1.5:
                    reason.append(f"High Vol (RVOL {latest['RVOL']:.1f})")
                    if criteria == "VOLUME_SPIKE":
                        match = True
                
                # Filter B: Discount (Value)
                if latest['close'] < latest['VWAP']:
                    reason.append("Discount (<VWAP)")
                    
                # Filter C: Momentum (Trend)
                if latest['MACD'] > latest['MACD_signal']:
                    reason.append("Bullish MACD")
                    if criteria == "MOMENTUM":
                        match = True
                        
                # UNIFIED Criteria (The Super Filter)
                # Requires Volume + (Value OR Momentum)
                if criteria == "UNIFIED":
                    # Must have Volume AND (Value OR Momentum)
                    if latest['RVOL'] > 1.2: # Slightly looser for screening to get more candidates
                         if (latest['close'] < latest['VWAP']) or (latest['MACD'] > latest['MACD_signal']):
                             match = True
                
                if match:
                    candidates.append({
                        "symbol": symbol,
                        "price": latest['close'],
                        "rvol": latest['RVOL'],
                        "reason": ", ".join(reason)
                    })
                    
            except Exception as e:
                logger.error(f"Error filtering {symbol}: {e}")
                continue
                
        logger.info(f"Scan complete. Found {len(candidates)} candidates.")
        return pd.DataFrame(candidates)
