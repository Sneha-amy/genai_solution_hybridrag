from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer
from reportlab.lib.styles import getSampleStyleSheet
import datetime


def generate_pdf_report(output_path, result):
    styles = getSampleStyleSheet()
    story = []

    # ---------------------------------------------------
    # COVER PAGE
    # ---------------------------------------------------
    title = Paragraph("<b>Financial Statement Anomaly Detection Report</b>", styles['Title'])
    date = Paragraph(f"<i>Generated on: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}</i>", styles['Normal'])
    
    story.append(title)
    story.append(Spacer(1, 0.2 * inch))
    story.append(date)
    story.append(Spacer(1, 0.5 * inch))

    # ---------------------------------------------------
    # EXECUTIVE SUMMARY
    # ---------------------------------------------------
    summary = Paragraph("<b>Executive Summary</b>", styles['Heading2'])
    story.append(summary)

    anomalies = result.get("combined_anomalies", [])
    summary_text = f"""
    This report summarizes detected anomalies, risk indicators, explainability outputs, and recommended actions 
    based on the uploaded financial statements. A total of <b>{len(anomalies)}</b> anomalies were detected.
    """
    story.append(Paragraph(summary_text, styles['BodyText']))
    story.append(Spacer(1, 0.3 * inch))

    # ---------------------------------------------------
    # KEY FINDINGS
    # ---------------------------------------------------
    story.append(Paragraph("<b>Key Findings</b>", styles['Heading2']))

    top_anoms = min(len(anomalies), 5)
    story.append(Paragraph(f"Top <b>{top_anoms}</b> anomalies with the highest severity score:", styles['BodyText']))
    story.append(Spacer(1, 0.2 * inch))

    # Build finding table (Top anomalies)
    rows = [["Account", "Period", "Value", "Reason"]]

    for a in anomalies[:top_anoms]:
        rows.append([
            a.get("account", "N/A"),
            a.get("period", "N/A"),
            a.get("value", "N/A"),
            a.get("reason", "N/A")
        ])

    table = Table(rows, colWidths=[1.5 * inch] * 4)
    table_style = TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER')
    ])
    table.setStyle(table_style)
    story.append(table)
    story.append(Spacer(1, 0.4 * inch))

    # ---------------------------------------------------
    # DETAILED ANOMALY SECTION
    # ---------------------------------------------------
    story.append(Paragraph("<b>Detailed Anomaly Report</b>", styles['Heading2']))
    story.append(Spacer(1, 0.1 * inch))

    rows = [["ID", "Account", "Period", "Value", "Deviation"]]

    for a in anomalies:
        rows.append([
            a.get("id"),
            a.get("account"),
            a.get("period"),
            str(a.get("value")),
            str(a.get("deviation", ""))
        ])

    table = Table(rows, colWidths=[1 * inch, 1.2 * inch, 1 * inch, 1 * inch, 1.2 * inch])
    table.setStyle(table_style)
    story.append(table)
    story.append(Spacer(1, 0.4 * inch))

    # ---------------------------------------------------
    # EXPLAINABILITY SECTION
    # ---------------------------------------------------
    story.append(Paragraph("<b>Explainability Breakdown</b>", styles['Heading2']))
    story.append(Spacer(1, 0.1 * inch))

    explain_sections = {
        "Rule Explainability": result.get("rule_explainability", []),
        "ML Explainability": result.get("ml_explainability", []),
        "Narrative Explainability": result.get("narrative_explainability", [])
    }

    for title, items in explain_sections.items():
        story.append(Paragraph(f"<b>{title}</b>", styles['Heading3']))
        for it in items:
            story.append(Paragraph(str(it), styles['BodyText']))
            story.append(Spacer(1, 0.1 * inch))

    # ---------------------------------------------------
    # RECOMMENDATIONS SECTION
    # ---------------------------------------------------
    story.append(Paragraph("<b>Recommendations</b>", styles['Heading2']))
    story.append(Spacer(1, 0.2 * inch))

    recs = result.get("recommendations", [])

    for rec in recs:
        story.append(Paragraph(f"<u>{rec.get('account')}</u>", styles['Heading3']))
        story.append(Paragraph(rec.get("recommendation", "No recommendation"), styles['BodyText']))
        story.append(Spacer(1, 0.3 * inch))

    # ---------------------------------------------------
    # MAKE PDF
    # ---------------------------------------------------
    doc = SimpleDocTemplate(output_path, pagesize=A4)
    doc.build(story)
