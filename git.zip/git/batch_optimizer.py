"""
Enhanced batch processing optimizations for 1000+ stocks
"""
import asyncio
import aiohttp
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import logging
from typing import List, Dict, Any
import json
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class BatchProcessor:
    def __init__(self, max_workers=10, batch_size=20, delay_between_batches=0.3):
        self.max_workers = max_workers
        self.batch_size = batch_size
        self.delay_between_batches = delay_between_batches
        self.success_count = 0
        self.fail_count = 0
        
    def process_stocks_optimized(self, symbol_tokens: Dict[str, str], fetch_function):
        """
        Optimized batch processing with:
        - Larger batch sizes (20 instead of 5)
        - More workers (10 instead of 5)
        - Shorter delays (0.3s instead of 0.5s)
        - Progress tracking
        """
        symbols = list(symbol_tokens.keys())
        total_symbols = len(symbols)
        batches = [symbols[i:i+self.batch_size] for i in range(0, total_symbols, self.batch_size)]
        
        logger.info(f"Processing {total_symbols} stocks in {len(batches)} batches of {self.batch_size}")
        
        all_results = []
        start_time = time.time()
        
        for batch_num, batch in enumerate(batches, 1):
            batch_start = time.time()
            logger.info(f"Batch {batch_num}/{len(batches)}: Processing {len(batch)} symbols")
            
            # Process batch in parallel
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                future_to_symbol = {
                    executor.submit(fetch_function, symbol, symbol_tokens[symbol]): symbol 
                    for symbol in batch
                }
                
                batch_results = []
                for future in as_completed(future_to_symbol):
                    symbol = future_to_symbol[future]
                    try:
                        result = future.result(timeout=30)  # 30s timeout per stock
                        if result:
                            batch_results.append(result)
                            self.success_count += 1
                        else:
                            self.fail_count += 1
                    except Exception as e:
                        logger.error(f"Failed {symbol}: {e}")
                        self.fail_count += 1
                
                all_results.extend(batch_results)
            
            batch_time = time.time() - batch_start
            progress = (batch_num / len(batches)) * 100
            eta = ((time.time() - start_time) / batch_num) * (len(batches) - batch_num)
            
            logger.info(f"Batch {batch_num} completed in {batch_time:.1f}s | "
                       f"Progress: {progress:.1f}% | ETA: {eta:.0f}s | "
                       f"Success: {self.success_count}, Failed: {self.fail_count}")
            
            # Rate limiting
            if batch_num < len(batches):
                time.sleep(self.delay_between_batches)
        
        total_time = time.time() - start_time
        logger.info(f"Completed processing {total_symbols} stocks in {total_time:.1f}s")
        logger.info(f"Success rate: {(self.success_count/total_symbols)*100:.1f}%")
        
        return all_results

    def adaptive_batch_processing(self, symbol_tokens: Dict[str, str], fetch_function):
        """
        Adaptive batch processing that adjusts based on success rate
        """
        symbols = list(symbol_tokens.keys())
        current_batch_size = self.batch_size
        current_delay = self.delay_between_batches
        
        all_results = []
        processed = 0
        
        while processed < len(symbols):
            batch = symbols[processed:processed + current_batch_size]
            batch_start = time.time()
            
            # Process batch
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                future_to_symbol = {
                    executor.submit(fetch_function, symbol, symbol_tokens[symbol]): symbol 
                    for symbol in batch
                }
                
                batch_success = 0
                batch_results = []
                
                for future in as_completed(future_to_symbol):
                    symbol = future_to_symbol[future]
                    try:
                        result = future.result(timeout=30)
                        if result:
                            batch_results.append(result)
                            batch_success += 1
                            self.success_count += 1
                        else:
                            self.fail_count += 1
                    except Exception as e:
                        logger.error(f"Failed {symbol}: {e}")
                        self.fail_count += 1
                
                all_results.extend(batch_results)
            
            # Adaptive adjustments
            success_rate = batch_success / len(batch)
            if success_rate < 0.7:  # Less than 70% success
                current_batch_size = max(5, current_batch_size - 5)
                current_delay += 0.1
                logger.warning(f"Low success rate ({success_rate:.1%}), reducing batch size to {current_batch_size}")
            elif success_rate > 0.9:  # More than 90% success
                current_batch_size = min(30, current_batch_size + 5)
                current_delay = max(0.1, current_delay - 0.05)
                logger.info(f"High success rate ({success_rate:.1%}), increasing batch size to {current_batch_size}")
            
            processed += len(batch)
            progress = (processed / len(symbols)) * 100
            logger.info(f"Progress: {progress:.1f}% | Batch size: {current_batch_size} | Delay: {current_delay:.1f}s")
            
            time.sleep(current_delay)
        
        return all_results

class CacheManager:
    """Simple caching to avoid re-fetching recent data"""
    
    def __init__(self, cache_duration_minutes=5):
        self.cache = {}
        self.cache_duration = timedelta(minutes=cache_duration_minutes)
    
    def get(self, symbol: str) -> Dict[str, Any]:
        if symbol in self.cache:
            data, timestamp = self.cache[symbol]
            if datetime.now() - timestamp < self.cache_duration:
                return data
        return None
    
    def set(self, symbol: str, data: Dict[str, Any]):
        self.cache[symbol] = (data, datetime.now())
    
    def clear_expired(self):
        now = datetime.now()
        expired = [
            symbol for symbol, (_, timestamp) in self.cache.items()
            if now - timestamp >= self.cache_duration
        ]
        for symbol in expired:
            del self.cache[symbol]

# Usage example for your existing code:
def optimized_fetch_with_cache(obj, symbol_tokens, cache_manager=None):
    """
    Enhanced version of your fetch_nse_data function
    """
    if not cache_manager:
        cache_manager = CacheManager()
    
    processor = BatchProcessor(max_workers=10, batch_size=20, delay_between_batches=0.3)
    
    def fetch_with_cache(symbol, token):
        # Check cache first
        cached_data = cache_manager.get(symbol)
        if cached_data:
            return cached_data
        
        # Fetch from API
        try:
            from angel_one_api import fetch_stock_data
            data = fetch_stock_data(obj, symbol, token)
            if data:
                cache_manager.set(symbol, data)
            return data
        except Exception as e:
            logger.error(f"Error fetching {symbol}: {e}")
            return None
    
    # Use adaptive processing for better performance
    results = processor.adaptive_batch_processing(symbol_tokens, fetch_with_cache)
    
    # Clean up expired cache entries
    cache_manager.clear_expired()
    
    return results