# langchain_agent.py

from langchain.agents import create_tool_calling_agent, AgentExecutor
from langchain_openai import ChatOpenAI
from langchain.tools import Tool
from langchain_core.prompts import ChatPromptTemplate
from typing import Any, Dict

import yaml
from pii_test import PiiRedactor
import os
import httpx
from dotenv import load_dotenv, find_dotenv

load_dotenv(find_dotenv())

client = httpx.Client(verify=False)
api_key = os.getenv("OPEN_AI_API_KEY")



# --------------------------------------------------------
# Load PII config + redactor
# --------------------------------------------------------
with open("config/pii.yaml", "r", encoding="utf-8") as f:
    pii_cfg = yaml.safe_load(f)

redactor = PiiRedactor(pii_cfg)


# --------------------------------------------------------
# TOOL 1 — Detect PII
# --------------------------------------------------------
def detect_pii(text: str) -> Dict[str, Any]:
    matches = redactor.detect(text)
    return {
        "pii_detected": [
            {"type": m.kind, "value": m.value}
            for m in matches
        ]
    }


# --------------------------------------------------------
# TOOL 2 — Redact PII
# --------------------------------------------------------
def redact_pii(text: str) -> Dict[str, Any]:
    matches = redactor.detect(text)
    redacted = redactor.redact(text)
    return {
        "original": text,
        "redacted": redacted,
        "pii_detected": [
            {"type": m.kind, "value": m.value}
            for m in matches
        ]
    }


# --------------------------------------------------------
# Wrap tools for LangChain agent
# --------------------------------------------------------
tools = [
    Tool(
        name="detect_pii",
        func=detect_pii,
        description="Detects PII inside user text and returns detected PII."
    ),
    Tool(
        name="redact_pii",
        func=redact_pii,
        description="Redacts PII and returns redacted text + PII details."
    ),
]


# --------------------------------------------------------
# AGENT SYSTEM PROMPT
# --------------------------------------------------------
SYSTEM_PROMPT = """
You are a PII-safety agent.

Your rules:
1. ALWAYS use tools — detect_pii or redact_pii — when users provide text.
2. NEVER output raw PII.
3. ALWAYS sanitize user text before doing anything else.
4. NEVER reconstruct, guess, or reveal PII.
5. If user requests any transformation of the text, run redaction first.
"""

prompt = ChatPromptTemplate.from_messages([
    ("system", SYSTEM_PROMPT),
    ("human", "{input}")
])


# --------------------------------------------------------
# CREATE AGENT USING create_agent (NEW API)
# --------------------------------------------------------
def create_pii_agent():
    llm = ChatOpenAI(
 base_url="https://genailab.tcs.in",
 model="azure_ai/genailab-maas-DeepSeek-V3-0324",
 api_key=api_key,
 http_client=client
)
    # This is the correct create_agent API for tool-calling agents
    agent = create_tool_calling_agent(
        llm=llm,
        tools=tools,
        prompt=prompt
    )

    executor = AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=True,
        handle_parsing_errors=True
    )

    return executor
