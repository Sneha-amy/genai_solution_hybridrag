import streamlit as st
import requests

API_URL = "http://localhost:8000/chat"

st.set_page_config(page_title="PII SafeChat", page_icon="🛡️")

if "messages" not in st.session_state:
    st.session_state.messages = []

st.title("🛡️ PII-Safe Chatbot")

user_input = st.chat_input("Type your message...")


if user_input:

    # Show user message
    st.session_state.messages.append(("user", user_input))

    payload = {"message": user_input, "user_id": "guest"}
    res = requests.post(API_URL, json=payload).json()

    # If safety blocked it
    if res["status"] == "blocked":
        bot_reply = f"⚠️ Blocked: {res['blocked_reason']}"
        st.session_state.messages.append(("bot", bot_reply))

    else:
        bot_reply = res["reply"]
        pii_found = res["pii_detected"]

        if pii_found:
            st.success(f"🔍 PII Detected & Redacted: {pii_found}")

        st.session_state.messages.append(("bot", bot_reply))


# Display chat messages
for role, msg in st.session_state.messages:
    st.chat_message("assistant" if role == "bot" else "user").write(msg)
