
export const sessionStore = {
  sessionId: null,
  applicants: [],
  setSession(id){ this.sessionId = id; },
  addApplicant(id){ if(!this.applicants.includes(id)) this.applicants.push(id); }
};
