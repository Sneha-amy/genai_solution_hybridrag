#!/usr/bin/env bash
# TODO: Paste the full run script from ChatGPT conversation here.
