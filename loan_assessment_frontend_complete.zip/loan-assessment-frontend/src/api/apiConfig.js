
export const API_BASE_URL = "http://localhost:8000";
export const ENDPOINTS = { ASSESSMENT: "/api/v1/assessments" };
