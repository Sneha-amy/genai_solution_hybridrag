# langchain_agent.py

from langchain.agents import create_agent
from langchain_openai import ChatOpenAI
from pii_test import process_text_with_safety, apply_output_filter


# --------------------------------------------------------
# 1. UNIFIED SAFETY + PII + REDACTION TOOL
# --------------------------------------------------------
def safety_sanitize_tool(text: str) -> str:
    """
    Runs:
      - Input guardrails
      - PII detection
      - PII redaction
      - Output filtering (only for sanitization step)
    Returns a string containing sanitized text and detected PII.
    """

    safe = process_text_with_safety(text)

    if safe["status"] == "blocked":
        return f"[BLOCKED]: {safe['error']}"

    redacted = safe["redacted"]
    pii_list = safe["pii_detected"]

    pii_msg = " | ".join([f"{p['type']}={p['value']}" for p in pii_list]) if pii_list else "None"

    return f"SANITIZED_TEXT: {redacted}\nPII_DETECTED: {pii_msg}"


# Wrap as a LangChain tool
tools = [
    safety_sanitize_tool
]


# --------------------------------------------------------
# 2. CREATE AGENT (NEW LANGCHAIN API)
# --------------------------------------------------------
def create_safe_agent():
    """
    Creates a LangChain Agent with:
      - One safety tool
      - Safe system prompt
      - A simple OpenAI LLM
    """

    agent = create_agent(
        model=ChatOpenAI(model="gpt-4o-mini", temperature=0.3),
        tools=tools,
        system_prompt="""\
You are a safety-first assistant.
You must:
- ALWAYS call the 'safety_sanitize_tool' before responding.
- NEVER reveal unredacted PII.
- NEVER override or undo masking.
- If sanitization returns [BLOCKED], output only the block reason.
After sanitization, answer normally using the sanitized text only.
"""
    )

    return agent


# --------------------------------------------------------
# 3. RUN AGENT WITH SAFETY PIPELINE
# --------------------------------------------------------
def run_agent_with_safety(user_input: str):
    """
    Runs:
      1. Agent → safety tool auto-call → sanitized text
      2. Agent final LLM answer
      3. Output guardrails applied again
    """

    agent = create_safe_agent()

    result = agent.invoke(
        {"messages": [{"role": "user", "content": user_input}]}
    )

    # Extract final answer
    final_reply = result["messages"][-1]["content"]

    # Final output filtering (against safety.yaml)
    safe_reply = apply_output_filter(final_reply)

    return {
        "reply": safe_reply,
        "status": "success"
    }


# --------------------------------------------------------
# 4. OPTIONAL STREAMING WRAPPER
# --------------------------------------------------------
def stream_agent_response(user_input: str):
    agent = create_safe_agent()

    for chunk in agent.stream(
        {"messages": [{"role": "user", "content": user_input}]},
        stream_mode="updates"
    ):
        yield chunk
