# pii_test.py

import re
import yaml

# ----------------------------------------------------
# Load PII YAML config
# ----------------------------------------------------
with open("config/pii.yaml", "r", encoding="utf-8") as f:
    PII_CFG = yaml.safe_load(f)["pii"]

# ----------------------------------------------------
# Load AI Safety Guardrails YAML
# ----------------------------------------------------
with open("config/safety.yaml", "r", encoding="utf-8") as f:
    SAFETY_CFG = yaml.safe_load(f)["ai_safety"]
    print(SAFETY_CFG.keys())


# ====================================================
# 1. INPUT SAFETY GUARDRAILS
# ====================================================
def run_input_guardrails(text: str):
    """
    Returns (True, None) if safe.
    Returns (False, reason) if unsafe.

    Applies:
        1. General content moderation
        2. Prompt injection detection
        3. Jailbreak prevention
        4. Domain-specific restrictions
    """

    # =====================================================
    # 1. GENERAL CONTENT MODERATION
    # =====================================================
    cm = SAFETY_CFG.get("content_moderation", {})
    print(cm)
    if cm.get("enabled", True):

        # banned keywords
        for keyword in cm.get("banned_keywords", []):
            if keyword.lower() in text.lower():
                return False, f"Blocked by content moderation: '{keyword}'"

        # banned categories (placeholder for classifier)
        for category in cm.get("banned_categories", []):
            # You can attach NLP classifier here later
            pass

        # length rule
        if len(text) > cm.get("max_input_length", 2000):
            return False, "Blocked: Input too long."

        # empty rule
        if cm.get("require_nonempty", True) and not text.strip():
            return False, "Blocked: Empty input is not allowed."


    # =====================================================
    # 2. PROMPT INJECTION DETECTION
    # =====================================================
    inj = SAFETY_CFG.get("prompt_injection", {})

    if inj.get("enabled", True):

        # forbidden phrases
        for phrase in inj.get("forbidden_phrases", []):
            if phrase.lower() in text.lower():
                return False, "Blocked: Prompt injection attempt."

        # suspicious regex patterns
        for pattern in inj.get("suspicious_patterns", {}).get("regex", []):
            if re.search(pattern, text, re.IGNORECASE):
                return False, "Blocked: Suspicious injection pattern."


    # =====================================================
    # 3. JAILBREAK PREVENTION
    # =====================================================
    jb = SAFETY_CFG.get("jailbreak_prevention", {})

    if jb.get("enabled", True):

        # disallowed jailbreak requests
        for phrase in jb.get("disallowed_requests", []):
            if phrase.lower() in text.lower():
                return False, "Blocked: Jailbreak attempt."

        # role override phrases
        for phrase in jb.get("role_override_phrases", []):
            if phrase.lower() in text.lower():
                return False, "Blocked: Role-override jailbreak attempt."

        # composite jailbreak regex
        for pattern in jb.get("composite_jailbreak_patterns", []):
            if re.search(pattern, text, re.IGNORECASE):
                return False, "Blocked: Composite jailbreak attempt."


    # =====================================================
    # 4. DOMAIN-SPECIFIC BUSINESS GUARDRAILS
    # =====================================================
    domain_rules = SAFETY_CFG.get("domain_rules", {})
    detected_domain = None

    # keyword map to detect which domain text belongs to
    domain_keywords = {
        "healthcare": ["disease", "diagnose", "symptom", "medicine", "treatment", "dose"],
        "finance": ["stock", "invest", "profit", "returns", "market", "crypto"],
        "banking": ["upi", "otp", "account", "transaction", "bank login"],
        "legal": ["court", "contract", "lawyer", "legal", "sue"],
        "cybersecurity": ["hack", "exploit", "ddos", "bypass", "malware", "rce"],
        "hr": ["hire", "fire", "candidate", "performance", "promotion"],
        "insurance": ["claim", "policy", "premium", "coverage"],
        "ecommerce": ["refund", "review", "rating", "customer issue"]
    }

    # Detect domain by scanning keywords
    for domain, kws in domain_keywords.items():
        if any(k.lower() in text.lower() for k in kws):
            detected_domain = domain
            break

    # Apply domain rules if matched
    if detected_domain and detected_domain in domain_rules:
        dr = domain_rules[detected_domain]

        # Block specific intents
        for intent in dr.get("block_intents", []):
            if intent.lower() in text.lower():
                print ("Blocked by {detected_domain} domain intent: '{intent}'")
                return False, f"Blocked by {detected_domain} domain intent: '{intent}'"

        # Block unsafe keywords
        for bad in dr.get("unsafe_keywords", []):
            if bad.lower() in text.lower():
                return False, f"Blocked by {detected_domain} risk keyword: '{bad}'"

        # Domain disclaimer will be added later at output processing


    # =====================================================
    # ALL CHECKS PASSED
    # =====================================================
    return True, None


# ====================================================
# 2. OUTPUT SAFETY FILTER
# ====================================================
def apply_output_filter(text: str) -> str:
    cfg = SAFETY_CFG.get("output_filtering", {})
    if not cfg.get("enabled", True):
        return text

    # If any disallowed phrase appears, we replace output fully
    for banned in cfg.get("block_if_contains", []):
        if banned.lower() in text.lower():
            strategy = cfg.get("redaction_strategy", "replace_output")

            # Replace entire output
            if strategy == "replace_output":
                return cfg.get("replacement_text", "[REDACTED_SAFETY]")

            # Replace only banned segment
            if strategy == "replace_segments":
                replacement = cfg.get("segment_replacement", "[FILTERED]")
                pattern = re.compile(re.escape(banned), re.IGNORECASE)
                return pattern.sub(replacement, text)

    return text


# ====================================================
# 3. PII DETECTION + REDACTION ENGINE (Your existing logic)
# ====================================================
class PiiMatch:
    def __init__(self, kind, value):
        self.kind = kind
        self.value = value


class PiiRedactor:

    def __init__(self, cfg):
        self.cfg = cfg

    # ----------------------------
    # PII DETECTION
    # ----------------------------
    def detect(self, text):
        matches = []
        detectors = self.cfg.get("detectors", [])

        for det in detectors:
            if not det.get("enabled", True):
                continue

            pattern = det.get("pattern")
            kind = det.get("name")
            group_index = det.get("group", 0)

            if pattern:
                for m in re.finditer(pattern, text, re.IGNORECASE):
                    value = m.group(group_index)
                    matches.append(PiiMatch(kind, value))

        return matches

    # ----------------------------
    # PII REDACTION
    # ----------------------------
    def redact(self, text):
        redacted = text
        detectors = self.cfg.get("detectors", [])

        for det in detectors:
            if not det.get("enabled", True):
                continue

            pattern = det.get("pattern")
            kind = det.get("name")

            if not pattern:
                continue

            redacted = re.sub(pattern,
                              f"[REDACTED_{kind}]",
                              redacted,
                              flags=re.IGNORECASE)
        return redacted


# Initialize global redactor instance
RED = PiiRedactor(PII_CFG)


# ====================================================
# 4. SAFE PROCESS FUNCTION (Expose this to main.py)
# ====================================================
def process_text_with_safety(text: str):
    """
    This is the only function you need to call from FastAPI or your agent.
    Applies:
        1) safety guardrails (input)
        2) pii detection
        3) pii redaction
        4) safety filtering (output)
    """

    # 1️⃣ RUN INPUT GUARDRAILS
    ok, msg = run_input_guardrails(text)
    if not ok:
        return {"error": msg, "status": "blocked"}

    # 2️⃣ DETECT PII
    pii_matches = RED.detect(text)

    # 3️⃣ REDACT TEXT
    redacted = RED.redact(text)

    # 4️⃣ APPLY OUTPUT FILTERING
    final_output = apply_output_filter(redacted)

    return {
        "status": "success",
        "input": text,
        "redacted": final_output,
        "pii_detected": [{ "type": m.kind, "value": m.value } for m in pii_matches]
    }
