#!/usr/bin/env python3
"""
Script to filter stocks by price range (30-300) and create CSV for analysis
"""

import csv
import time
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from angel_one_api import login_angel_one
from TOKEN_MAP import TOKEN_MAP

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_current_price(obj, symbol, token):
    """Get current price for a single stock"""
    try:
        # Try LTP (Last Traded Price) first - more reliable for current prices
        try:
            ltp_data = obj.ltpData("NSE", symbol, token)
            if ltp_data and ltp_data.get('status') and ltp_data.get('data'):
                ltp = ltp_data['data'].get('ltp')
                if ltp:
                    return float(ltp)
        except Exception as ltp_error:
            logger.debug(f"LTP failed for {symbol}: {ltp_error}")
        
        # Fallback to historical data with adjusted parameters
        from datetime import datetime, timedelta
        
        # Use a wider date range
        to_date = datetime.now().strftime("%Y-%m-%d 15:30")
        from_date = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d 09:15")
        
        params = {
            "exchange": "NSE",
            "symboltoken": token,
            "interval": "ONE_DAY",
            "fromdate": from_date,
            "todate": to_date
        }
        
        hist_data = obj.getCandleData(params)
        
        if hist_data and isinstance(hist_data, dict):
            if 'Access denied' in str(hist_data) or hist_data.get('message') == 'Access denied':
                logger.warning(f"Access denied for {symbol}")
                return None
                
            if hist_data.get('status') and hist_data.get('data'):
                data = hist_data['data']
                if data and len(data) > 0:
                    latest = data[-1]
                    if len(latest) > 4:
                        price = float(latest[4])  # Close price
                        return price
        
        return None
        
    except Exception as e:
        logger.error(f"Error getting price for {symbol}: {e}")
        return None

def filter_stocks_by_price():
    """Filter stocks with price between 30-300 and save to CSV"""
    logger.info("Starting price filtering process...")
    
    # Login to Angel One
    obj = login_angel_one()
    if not obj:
        logger.error("Failed to login to Angel One API")
        return
    
    filtered_stocks = []
    total_stocks = len(TOKEN_MAP)
    processed = 0
    
    # Process in smaller batches to avoid rate limits
    batch_size = 5
    symbols_list = list(TOKEN_MAP.items())
    batches = [symbols_list[i:i+batch_size] for i in range(0, len(symbols_list), batch_size)]
    
    for batch_num, batch in enumerate(batches, 1):
        logger.info(f"Processing batch {batch_num}/{len(batches)}")
        
        with ThreadPoolExecutor(max_workers=2) as executor:
            future_to_symbol = {
                executor.submit(get_current_price, obj, symbol, token): (symbol, token)
                for symbol, token in batch
            }
            
            for future in as_completed(future_to_symbol):
                symbol, token = future_to_symbol[future]
                processed += 1
                
                try:
                    price = future.result()
                    if price and 30 <= price <= 300:
                        filtered_stocks.append({
                            'symbol': symbol,
                            'token': token,
                            'price': round(price, 2)
                        })
                        logger.info(f"✓ {symbol}: ₹{price:.2f}")
                    elif price:
                        logger.debug(f"✗ {symbol}: ₹{price:.2f} (out of range)")
                    else:
                        logger.debug(f"✗ {symbol}: No price data")
                        
                except Exception as e:
                    logger.debug(f"✗ {symbol}: {e}")
        
        # Progress update
        logger.info(f"Progress: {processed}/{total_stocks} ({processed/total_stocks*100:.1f}%)")
        
        # Longer delay between batches to avoid rate limits
        if batch_num < len(batches):
            time.sleep(0.5)
    
    # Save to CSV
    csv_filename = 'filtered_stocks_30_300.csv'
    with open(csv_filename, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = ['symbol', 'token', 'price']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        for stock in sorted(filtered_stocks, key=lambda x: x['symbol']):
            writer.writerow(stock)
    
    logger.info(f"\n{'='*60}")
    logger.info(f"PRICE FILTERING COMPLETE")
    logger.info(f"{'='*60}")
    logger.info(f"Total stocks processed: {processed}")
    logger.info(f"Stocks in price range (₹30-₹300): {len(filtered_stocks)}")
    logger.info(f"CSV file created: {csv_filename}")
    logger.info(f"{'='*60}")
    
    return filtered_stocks

if __name__ == "__main__":
    filter_stocks_by_price()