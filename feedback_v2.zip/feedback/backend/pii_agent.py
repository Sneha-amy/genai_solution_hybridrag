# langchain_agent.py

from langchain_openai import ChatOpenAI
from langchain.agents import create_react_agent
from langchain.prompts import PromptTemplate
from pii_test import process_text_with_safety
from pii_test import apply_output_filter

# -----------------------------------------------------------
# 1. Base LLM
# -----------------------------------------------------------
llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0.2
)

# -----------------------------------------------------------
# 2. SYSTEM PROMPT (Safe Prompt)
# -----------------------------------------------------------
SYSTEM_PROMPT = """
You are a safe assistant. 
You MUST:
- Accept already-sanitized user input
- Never attempt to unmask redacted PII
- Never request private information
- Follow safety, ethics, and compliance rules
- Provide helpful yet non-harmful responses
"""

prompt = PromptTemplate.from_template("""
{system_prompt}

User message (already sanitized): {input}

Your safe answer:
""")

# -----------------------------------------------------------
# 3. SAFE AGENT (NO tools, NO unsafe operations)
# -----------------------------------------------------------
def create_safe_agent():
    """Returns a simple langchain LLM wrapper agent."""

    agent = create_react_agent(
        llm=llm,
        tools=[],  # NO TOOLS FOR SAFETY
        prompt=prompt.partial(system_prompt=SYSTEM_PROMPT)
    )

    return agent


# -----------------------------------------------------------
# 4. UNIFIED SAFE CALL
# -----------------------------------------------------------
def run_agent_with_safety(user_text: str):
    """
    - Runs input guardrails
    - Detects + redacts PII
    - Sends sanitized text to agent
    - Applies output filtering again
    """

    # Step 1: Guardrails + PII
    safe = process_text_with_safety(user_text)

    if safe["status"] == "blocked":
        return {
            "reply": None,
            "sanitized_input": None,
            "blocked_reason": safe["error"],
            "status": "blocked"
        }

    sanitized = safe["redacted"]
    pii_found = safe["pii_detected"]

    # Step 2: LLM agent call
    agent = create_safe_agent()

    try:
        llm_output = agent.invoke({"input": sanitized})
        reply_text = llm_output["output"]
    except Exception as e:
        reply_text = f"[LLM ERROR] {str(e)}"

    # Step 3: Output filtering
    filtered_reply = apply_output_filter(reply_text)

    return {
        "reply": filtered_reply,
        "sanitized_input": sanitized,
        "pii_detected": pii_found,
        "status": "success"
    }
