# graph/models.py
from pydantic import BaseModel
from typing import Optional
import pandas as pd
from typing import List, Any, Dict
from graph.state import PipelineState
from rag.ifrs_rag import IFRSRAG

from langchain_openai import ChatOpenAI
import uuid
from sklearn.ensemble import IsolationForest
import pandas as pd
import numpy as np
import uuid
import re


#llm_reco = ChatOpenAI(    model="gpt-4o-mini",    temperature=0.2)
rag_engine = IFRSRAG()   # Initialize once



class BaseAnomaly(BaseModel):
    id: str
    account: Optional[str] = None
    statement_type: Optional[str] = None
    period: Optional[str] = None
    severity: str  # "low", "medium", "high"
    description: str
    source: str  # "rule" or "ml"

class ComplianceAnomaly(BaseAnomaly):
    ifrs_refs: list = []
    compliance_summary: Optional[str] = None

class FinalAnomaly(ComplianceAnomaly):
    explanation: Optional[str] = None
    recommendation: Optional[str] = None
    


#llm_reco = ChatOpenAI(    model="gpt-4o-mini",    temperature=0.2)

def rule_explainability_node(state):
    rule_anomalies = state.rule_anomalies

    if not rule_anomalies:
        return {"rule_explainability": []}

    explanations = []

    for anomaly in rule_anomalies:
        rule_key = anomaly.get("rule_key")  # rule identifier
        rule_info = RULE_EXPLANATION_MAP.get(rule_key)

        if not rule_info:
            explanations.append({
                "anomaly_id": anomaly["id"],
                "rule_name": rule_key or "Unknown Rule",
                "explanation": "No explanation template available.",
            })
            continue

        template = rule_info["template"]

        # Extract anomaly values
        values = anomaly.get("details", {})

        try:
            explanation_text = template.format(**values)
        except Exception:
            explanation_text = "Explanation formatting failed due to missing values."

        explanations.append({
            "anomaly_id": anomaly["id"],
            "rule_name": rule_info["name"],
            "explanation": explanation_text,
            "details": values
        })

    return {"rule_explainability": explanations}


def recommendation_node(state: PipelineState) -> dict:
    """
    Recommendation Node
    -------------------
    Converts compliance_enriched anomalies into:
      - explanation
      - recommendation
      - business impact

    Output: state.recommendations
    """

    try:
        enriched = state.compliance_enriched or []
        if not enriched:
            return {"recommendations": []}

        results = []

        for anomaly in enriched:

            anomaly_text = anomaly.get("description", "No description available")
            compliance_text = anomaly.get("compliance_summary", "")

            prompt = f"""
            You are a senior financial analyst and IFRS-compliant auditor.

            Given the following anomaly and IFRS explanation, produce:

            1. A simple explanation (2–3 sentences) of what the issue means.
            2. A recommended corrective action (2–3 sentences).
            3. A business impact (1–2 sentences) describing why this matters.

            Keep the language:
            - clear
            - actionable
            - non-technical
            - appropriate for CFO/executive reporting.

            ANOMALY:
            {anomaly_text}

            IFRS_EXPLANATION:
            {compliance_text}
            """

            try:
                response = llm_reco.predict(prompt)
            except Exception as e_llm:
                response = f"Unable to generate recommendation: {e_llm}"

            final_output = {
                **anomaly,
                "explanation": response,
                "recommendation": response,  # You can split these if needed
                "business_impact": None,      # Can be extracted later
            }

            results.append(final_output)

        return {"recommendations": results}

    except Exception as e:
        return {"errors": state.errors + [f"Recommendation Node Error: {e}"]}


def ml_anomaly_node(state: PipelineState) -> dict:
    """
    ML Anomaly Detection using Isolation Forest.
    
    Input:
        state.df_normalized -> long format:
             statement_type | period | account | value

    Output:
        state.ml_anomalies -> list of BaseAnomaly dicts
    """

    try:
        df = state.df_normalized
        if df is None or df.empty:
            return {"ml_anomalies": []}

        # -----------------------------------------------------------
        # 1. Prepare pivot table: account x periods
        # -----------------------------------------------------------
        pivot = df.pivot_table(
            index=["statement_type", "account"],
            columns="period",
            values="value",
            aggfunc="sum"
        ).fillna(0)

        if pivot.empty:
            return {"ml_anomalies": []}

        # Ensure numeric matrix
        X = pivot.values

        # -----------------------------------------------------------
        # 2. Fit Isolation Forest
        # -----------------------------------------------------------
        model = IsolationForest(
            contamination=0.10,
            random_state=42
        )
        preds = model.fit_predict(X)
        scores = model.decision_function(X)

        pivot["pred"] = preds
        pivot["score"] = scores

        # -----------------------------------------------------------
        # 3. Extract anomalies (pred = -1)
        # -----------------------------------------------------------
        pivot_anom = pivot[pivot["pred"] == -1]

        anomalies = []

        for (statement_type, account), row in pivot_anom.iterrows():
            for period in pivot.columns:
                if period in ["pred", "score"]:
                    continue

                value = row[period]

                anomalies.append(
                    BaseAnomaly(
                        id="ml-" + str(uuid.uuid4())[:8],
                        account=account,
                        statement_type=statement_type,
                        period=str(period),
                        severity=_severity_from_score(row["score"]),
                        description=f"ML anomaly detected for {account} in {period}. Score={row['score']:.4f}. Value={value}",
                        source="ml"
                    ).dict()
                )

        return {"ml_anomalies": anomalies}

    except Exception as e:
        return {"errors": state.errors + [f"ML Anomaly Error: {e}"]}


def compliance_node(state: PipelineState) -> dict:
    """
    For each anomaly:
      - Retrieve IFRS references based on anomaly description
      - Generate a short compliance summary
    """

    try:
        anomalies = state.combined_anomalies
        if not anomalies:
            return {"compliance_enriched": []}

        enriched = []

        for anomaly in anomalies:
            query = anomaly["description"]

            # === IFRS Retrieval ===
            docs = rag_engine.search(query, k=3)

            # Extract the text for output
            ifrs_refs = [d.page_content for d in docs]

            # === IFRS Summary Generation ===
            summary = rag_engine.summarize(query, docs)

            anomaly_enriched = {
                **anomaly,
                "ifrs_refs": ifrs_refs,
                "compliance_summary": summary
            }

            enriched.append(anomaly_enriched)

        return {"compliance_enriched": enriched}

    except Exception as e:
        return {"errors": state.errors + [f"Compliance RAG Error: {e}"]}

def materiality_node(state):
    df = state.df_normalized
    combined = state.combined_anomalies

    if df is None or df.empty or not combined:
        return {"materiality_scores": []}

    # Get total assets (best effort fuzzy)
    assets = df[df["account"].str.contains("asset", case=False, na=False)]
    total_assets = assets["value"].max() if not assets.empty else None

    if not total_assets or total_assets == 0:
        # Materiality cannot be computed
        return {"materiality_scores": []}

    results = []

    for anomaly in combined:
        value = anomaly.get("value", 0)
        anomaly_id = anomaly.get("id", "unknown")

        mat = abs(value) / total_assets

        if mat >= 0.10:
            level = "high"
        elif mat >= 0.03:
            level = "medium"
        else:
            level = "low"

        results.append({
            "anomaly_id": anomaly_id,
            "materiality": mat,
            "level": level,
            "value": value,
            "total_assets": total_assets
        })

    return {"materiality_scores": results}

def severity_scoring_node(state):
    rule_anoms = {a["id"]: a for a in state.rule_anomalies}
    ml_anoms = {a["id"]: a for a in state.ml_anomalies}
    materiality = {m["anomaly_id"]: m for m in state.materiality_scores}

    results = []

    for combined in state.combined_anomalies:

        anomaly_id = combined["id"]

        # Rule weight
        rule_score = 1.0 if anomaly_id in rule_anoms else 0.2

        # ML weight
        ml_score = 1.0 if anomaly_id in ml_anoms else 0.2

        # Trend weight (optional)
        acct = combined["account"]
        acct_trend = [
            t for t in state.trend_analysis if t["account"] == acct
        ]

        if acct_trend:
            t = acct_trend[0]
            if t["trend_label"] == "significant_change":
                trend_score = 1.0
            elif t["trend_label"] == "moderate_change":
                trend_score = 0.5
            else:
                trend_score = 0.1
        else:
            trend_score = 0.1

        # Materiality weight
        mat = materiality.get(anomaly_id)
        if mat:
            if mat["level"] == "high":
                mat_score = 1.0
            elif mat["level"] == "medium":
                mat_score = 0.6
            else:
                mat_score = 0.3
        else:
            mat_score = 0.2

        # Weighted final score
        final = (
            0.3 * rule_score +
            0.3 * ml_score +
            0.2 * trend_score +
            0.2 * mat_score
        )

        results.append({
            "anomaly_id": anomaly_id,
            "severity_score": round(final, 3),
            "rule_score": rule_score,
            "ml_score": ml_score,
            "trend_score": trend_score,
            "materiality_score": mat_score
        })

    return {"anomaly_scores": results}



def ingestion_node(state):
    files = state.files
    all_rows = []

    for file in files:
        try:
            # Read ALL sheets
            xls = pd.read_excel(file, sheet_name=None)
        except Exception:
            continue

        for sheet_name, df in xls.items():
            if df.empty:
                continue

            # Strip whitespace from column names
            df.columns = df.columns.str.strip()

            # -----------------------------------------
            # 1. Auto-detect the Account column
            # -----------------------------------------
            account_col = None
            for col in df.columns:
                if re.search(r"account|desc|name|item", col, re.IGNORECASE):
                    account_col = col
                    break

            # If not found, use first column as fallback
            if not account_col:
                account_col = df.columns[0]

            # -----------------------------------------
            # 2. Auto-detect year / period columns
            # -----------------------------------------
            period_cols = [
                col for col in df.columns
                if re.match(r"^\d{4}$", str(col))  # matches 2023, 2024, etc.
                or "period" in col.lower()
                or re.match(r"^\d{4}-\d{2}$", str(col))  # 2023-01
            ]

            # Skip sheet if no period columns found
            if not period_cols:
                continue

            # -----------------------------------------
            # 3. Convert numeric values safely
            # -----------------------------------------
            for col in period_cols:
                df[col] = pd.to_numeric(df[col], errors="coerce")

            # Drop rows with no data
            df = df.dropna(subset=period_cols, how="all")
            if df.empty:
                continue

            # -----------------------------------------
            # 4. Melt into long format:
            #    Account | Period | Value
            # -----------------------------------------
            melted = df.melt(
                id_vars=[account_col],
                value_vars=period_cols,
                var_name="period",
                value_name="value"
            )

            # Clean account names
            melted["account"] = melted[account_col].astype(str).str.strip()
            melted = melted.dropna(subset=["value"])

            all_rows.append(melted[["account", "period", "value"]])

    # -----------------------------------------
    # Final concatenation
    # -----------------------------------------
    if not all_rows:
        state.df_normalized = []
        return {"df_normalized": []}

    df_final = pd.concat(all_rows, ignore_index=True)

    # Normalize period column into string
    df_final["period"] = df_final["period"].astype(str)

    state.df_normalized = df_final.to_dict(orient="records")
    return {"df_normalized": state.df_normalized}




def recommendation_node(state):
    anomalies = state.combined_anomalies
    if not anomalies:
        return {"recommendations": []}

    rule_map = {r["anomaly_id"]: r for r in state.rule_explainability or []}
    ml_map   = {m["anomaly_id"]: m for m in state.ml_explainability or []}
    mat_map  = {m["anomaly_id"]: m for m in state.materiality_scores or []}
    sev_map  = {s["anomaly_id"]: s for s in state.anomaly_scores or []}

    # trend lookup by account
    trend_idx = {t["account"]: t for t in state.trend_analysis or []}

    recommendations = []

    for anomaly in anomalies:
        aid = anomaly["id"]
        account = anomaly.get("account")
        period = anomaly.get("period")

        data = {
            "anomaly": anomaly,
            "rule_explanation": rule_map.get(aid),
            "ml_explanation": ml_map.get(aid),
            "trend": trend_idx.get(account),
            "materiality": mat_map.get(aid),
            "severity": sev_map.get(aid),
        }

        prompt = f"""
You are a senior financial auditor.

Write a short, direct recommendation (2 sentences + 3 concise bullets) 
for the following anomaly. Avoid long paragraphs.

DATA:
{data}

Your output MUST follow this format:

Summary:
- One short sentence summarizing the issue and severity.

Recommendations:
- Bullet 1
- Bullet 2
- Bullet 3
"""

        try:
            text = llm.predict(prompt).strip()
        except Exception as e:
            text = f"Recommendation unavailable: {e}"

        recommendations.append({
            "anomaly_id": aid,
            "account": account,
            "period": period,
            "recommendation": text
        })

    return {"recommendations": recommendations}


def narrative_explainability_node(state):
    combined = state.combined_anomalies
    if not combined:
        return {"narrative_explainability": []}

    rule_map = {e["anomaly_id"]: e for e in state.rule_explainability or []}
    ml_map   = {e["anomaly_id"]: e for e in state.ml_explainability or []}
    mat_map  = {e["anomaly_id"]: e for e in state.materiality_scores or []}
    sev_map  = {e["anomaly_id"]: e for e in state.anomaly_scores or []}

    trend_map = {}
    for t in state.trend_analysis or []:
        trend_map[(t["account"], tuple(t["periods"]))] = t

    narratives = []

    for anomaly in combined:
        anomaly_id = anomaly["id"]
        account = anomaly.get("account")
        period = anomaly.get("period")

        # Lookup components
        rule_exp = rule_map.get(anomaly_id)
        ml_exp = ml_map.get(anomaly_id)
        mat_exp = mat_map.get(anomaly_id)
        sev_exp = sev_map.get(anomaly_id)

        trend_exp = None
        for key, t in trend_map.items():
            if account == t["account"]:
                trend_exp = t
                break

        # -----------------------------
        # Build LLM prompt
        # -----------------------------

        prompt = f"""
You are an expert financial auditor.

Summarize the following anomaly in clear, concise natural language that a CFO can read quickly.

Include:
- What the anomaly is
- Why it was flagged
- Statistical or rule-based issues
- Trend deviation if available
- Materiality assessment
- Final severity / business impact

Use 2–4 sentences maximum.

DATA:
- Anomaly: {anomaly}
- Rule explanation: {rule_exp}
- ML explanation: {ml_exp}
- Trend: {trend_exp}
- Materiality: {mat_exp}
- Severity: {sev_exp}
"""

        try:
            narrative = llm.predict(prompt).strip()
        except Exception as e:
            narrative = f"Narrative generation failed: {e}"

        narratives.append({
            "anomaly_id": anomaly_id,
            "account": account,
            "period": period,
            "narrative": narrative
        })

    return {"narrative_explainability": narratives}


def ml_explainability_node(state):
    ml_anoms = state.ml_anomalies
    df = state.df_normalized

    if not ml_anoms or df is None or df.empty:
        return {"ml_explainability": []}

    explanations = []

    # Pivot for statistical comparison
    pivot = df.pivot_table(
        index=["statement_type", "account"],
        columns="period",
        values="value",
        aggfunc="sum"
    ).fillna(0)

    for anam in ml_anoms:
        acct = anam.get("account")
        period = anam.get("period")
        value = anam.get("value")
        score = anam.get("score")  # from ML node

        # Get historical values for this account
        try:
            row = pivot.loc[(anam["statement_type"], acct)]
        except KeyError:
            row = None

        top_contrib = []
        explanation = ""
        method = "isolation_forest" if score is not None else "zscore_fallback"

        if row is not None and period in row.index:
            # Extract per-period context
            values = row.values.astype(float)
            curr = value
            prev_vals = [v for p, v in row.items() if p != period]

            if prev_vals:
                mean_prev = float(np.mean(prev_vals))
                std_prev = float(np.std(prev_vals)) if np.std(prev_vals) != 0 else 1e-6
                z = (curr - mean_prev) / std_prev

                top_contrib.append(f"Current value {curr} vs previous mean {mean_prev:.2f}")
                top_contrib.append(f"Z-score deviation: {z:.2f}")

                explanation = (
                    f"The value for {acct} in {period} deviates from historical patterns. "
                    f"It is {z:.2f} standard deviations away from the mean."
                )
            else:
                explanation = f"Insufficient history to compute deviation for {acct}."

        # If Isolation Forest scored heavily negative = stronger anomaly
        if score is not None and score < -0.2:
            top_contrib.append(f"Isolation Forest score: {score:.3f}")
            explanation += " Model confidence in anomaly is high."

        explanations.append({
            "anomaly_id": anam["id"],
            "account": acct,
            "period": period,
            "method": method,
            "score": score,
            "top_contributors": top_contrib,
            "explanation": explanation
        })

    return {"ml_explainability": explanations}

        
def trend_analysis_node(state):
    df = state.df_normalized
    if df is None or df.empty:
        return {"trend_analysis": []}

    trend_results = []

    # Pivot into wide format for trend analysis
    pivot = df.pivot_table(
        index=["statement_type", "account"],
        columns="period",
        values="value",
        aggfunc="sum"
    ).fillna(0)

    # If only 1 period exists — cannot compute trend
    if pivot.shape[1] < 2:
        return {"trend_analysis": []}

    periods = list(pivot.columns)

    # Compute trend for every account
    for (stype, acct), row in pivot.iterrows():

        values = row.values.astype(float)

        if len(values) < 2:
            continue

        v_old = values[0]
        v_new = values[-1]

        if v_old == 0:
            change_pct = None
        else:
            change_pct = ((v_new - v_old) / abs(v_old)) * 100

        label = "normal"

        if change_pct is not None:
            if abs(change_pct) > 30:
                label = "significant_change"
            elif abs(change_pct) > 15:
                label = "moderate_change"

        trend_results.append({
            "statement_type": stype,
            "account": acct,
            "periods": periods,
            "change_pct": change_pct,
            "trend_label": label
        })

    return {"trend_analysis": trend_results}      
        
def rule_engine_node(state: PipelineState) -> dict:
    """
    Deterministic Accounting Rule Checks.
    Works ONLY on df_normalized.
    
    Rules implemented:
      1. Balance Sheet Identity: Assets = Liabilities + Equity
      2. Gross Profit check: Gross Profit = Revenue - COGS
      3. Operating Profit check
      4. Negative value checks
    """

    try:
        df = state.df_normalized
        if df is None or df.empty:
            return {"rule_anomalies": []}

        anomalies = []

        # ------------------------------------------------------------------
        # 1. BALANCE SHEET IDENTITY
        # ------------------------------------------------------------------
        bs = df[df["statement_type"] == "balance_sheet"]

        if not bs.empty:
            periods = bs["period"].unique()
            for p in periods:
                sub = bs[bs["period"] == p]

                total_assets = _get_value(sub, "total assets")
                total_liab = _get_value(sub, "total liabilities")
                total_equity = _get_value(sub, "total equity")

                if total_assets is not None and total_liab is not None and total_equity is not None:
                    if abs(total_assets - (total_liab + total_equity)) > 1e-6:
                        anomalies.append(
                            _make_rule_anomaly(
                                "Total Assets",
                                p,
                                f"Assets ({total_assets}) ≠ Liabilities + Equity ({total_liab + total_equity})",
                                severity="high"
                            )
                        )

        # ------------------------------------------------------------------
        # 2. GROSS PROFIT CHECK
        # ------------------------------------------------------------------
        pl = df[df["statement_type"] == "income_statement"]

        if not pl.empty:
            periods = pl["period"].unique()
            for p in periods:
                sub = pl[pl["period"] == p]

                revenue = _get_value(sub, "revenue")
                cogs = _get_value(sub, "cogs")
                gross_profit = _get_value(sub, "gross profit")

                if revenue is not None and cogs is not None and gross_profit is not None:
                    if abs(gross_profit - (revenue - cogs)) > 1e-6:
                        anomalies.append(
                            _make_rule_anomaly(
                                "Gross Profit",
                                p,
                                f"Gross Profit ({gross_profit}) ≠ Revenue - COGS ({revenue - cogs})",
                                severity="medium"
                            )
                        )

        # ------------------------------------------------------------------
        # 3. NEGATIVE VALUE CHECKS
        # ------------------------------------------------------------------
        neg = df[df["value"] < 0]
        for _, row in neg.iterrows():
            anomalies.append(
                _make_rule_anomaly(
                    row["account"],
                    row["period"],
                    f"Negative value detected: {row['account']} = {row['value']}",
                    severity="medium"
                )
            )

        # ------------------------------------------------------------------
        # Return sanitized anomalies
        # ------------------------------------------------------------------
        return {"rule_anomalies": anomalies}

    except Exception as e:
        return {"errors": state.errors + [f"Rule Engine Error: {e}"]}


def merge_anomalies_node(state: PipelineState) -> dict:
    """
    Merge anomalies from:
        - rule_anomalies
        - ml_anomalies

    Produces:
        combined_anomalies
    """

    try:
        rule_anoms = state.rule_anomalies or []
        ml_anoms = state.ml_anomalies or []

        # ---------------------------------------------------
        # Merge anomalies
        # ---------------------------------------------------
        merged = rule_anoms + ml_anoms

        # ---------------------------------------------------
        # Deduplicate by (account, period, source, description)
        # ---------------------------------------------------
        seen = set()
        deduped = []

        for anom in merged:
            sig = (
                anom.get("account"),
                anom.get("period"),
                anom.get("source"),
                anom.get("description")
            )
            if sig not in seen:
                seen.add(sig)
                deduped.append(anom)

        return {"combined_anomalies": deduped}

    except Exception as e:
        return {"errors": state.errors + [f"Merge Node Error: {e}"]}




def _get_value(df, account_name):
    """Fetch account values with flexible matching."""
    account_name = account_name.lower()

    for _, row in df.iterrows():
        if str(row["account"]).lower() == account_name:
            return row["value"]

    return None


def _make_rule_anomaly(account, period, description, severity="medium"):
    return BaseAnomaly(
        id="rule-" + str(uuid.uuid4())[:8],
        account=account,
        statement_type=None,
        period=str(period),
        severity=severity,
        description=description,
        source="rule"
    ).dict()


# -----------------------------------------------------------------
# Excel Processor
# -----------------------------------------------------------------

def _process_excel_file(filepath: str) -> pd.DataFrame:
    """
    Reads all sheets and tries to classify them into:
      - balance_sheet
      - income_statement
      - cashflow_statement

    Normalizes into long-format:
        statement_type | period | account | value
    """

    xls = pd.ExcelFile(filepath)
    results = []

    for sheet in xls.sheet_names:
        df_raw = xls.parse(sheet)
        statement_type = _guess_statement_type(sheet, df_raw)
        df_norm = _normalize_financial_df(df_raw, statement_type)
        results.append(df_norm)

    return pd.concat(results, ignore_index=True)


# -----------------------------------------------------------------
# PDF Processor (placeholder)
# -----------------------------------------------------------------

def _process_pdf_file(filepath: str) -> pd.DataFrame:
    """
    Extracts tables from PDF.
    TODO: Implement Camelot or pdfplumber extraction.
    """
    # Placeholder to keep pipeline running
    return pd.DataFrame(
        columns=["statement_type", "period", "account", "value"]
    )


# -----------------------------------------------------------------
# Heuristics to guess statement type
# -----------------------------------------------------------------

def _guess_statement_type(sheet_name: str, df: pd.DataFrame) -> str:
    s = sheet_name.lower()

    if "balance" in s:
        return "balance_sheet"
    if "income" in s or "p&l" in s or "profit" in s:
        return "income_statement"
    if "cash" in s:
        return "cashflow_statement"

    # fallback (can refine later)
    return "unknown"


# -----------------------------------------------------------------
# Normalize financial tables into final pipeline-ready format
# -----------------------------------------------------------------

def _normalize_financial_df(df_raw: pd.DataFrame, statement_type: str) -> pd.DataFrame:
    """
    Converts wide-format sheets into:
       account | 2023 | 2024 | ... → long format
    """
    df = df_raw.copy()

    # Identify period columns (simple heuristic)
    period_cols = [c for c in df.columns if str(c).isdigit()]

    if not period_cols:
        return pd.DataFrame(
            columns=["statement_type", "period", "account", "value"]
        )

    # Melt into long format
    df_long = df.melt(
        id_vars=[df.columns[0]],  # assume first column = account
        value_vars=period_cols,
        var_name="period",
        value_name="value"
    )

    df_long.columns = ["account", "period", "value"]

    # Add statement type
    df_long["statement_type"] = statement_type

    # Reorder columns
    return df_long[["statement_type", "period", "account", "value"]]


def _severity_from_score(score: float) -> str:
    """
    Map Isolation Forest score to severity.
    Lower score = more anomalous.
    """
    if score < -0.25:
        return "high"
    if score < -0.05:
        return "medium"
    return "low"

def _extract_text_from_pdf(pdf_path: str) -> str:
    """
    Convert PDF pages → images → OCR text.
    Works for scanned statements or image-based PDFs.
    """
    try:
        pages = convert_from_path(pdf_path, dpi=300)
    except Exception as e:
        print(f"[OCR] Failed to render PDF pages: {e}")
        return ""

    full_text = ""
    for i, page in enumerate(pages):
        try:
            text = pytesseract.image_to_string(page)
            full_text += "\n" + text
        except Exception as e:
            print(f"[OCR] Failed on page {i}: {e}")

    return full_text.strip()


# ---------------------------
# 2. Parse OCR text into financial DataFrame
# ---------------------------
def _parse_ocr_financial_text(text: str) -> pd.DataFrame:
    """
    Convert OCR-extracted text into approximate financial table structure:
    account | 2023 | 2024
    using NAME NUMBER NUMBER regex.
    """

    rows = []
    lines = text.split("\n")
    pattern = re.compile(r"(.+?)\s+([\d,]+)\s+([\d,]+)")

    for line in lines:
        match = pattern.match(line.strip())
        if match:
            account = match.group(1).strip()
            v1 = match.group(2).replace(",", "")
            v2 = match.group(3).replace(",", "")
            rows.append([account, v1, v2])

    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows, columns=["Account", "2023", "2024"])
    df["2023"] = pd.to_numeric(df["2023"], errors="coerce")
    df["2024"] = pd.to_numeric(df["2024"], errors="coerce")

    # Melt into normalized format
    df_long = df.melt(id_vars="Account", var_name="period", value_name="value")
    df_long["statement_type"] = "unknown"
    df_long.columns = ["account", "period", "value", "statement_type"]

    return df_long


def _safe_normalize(df_raw: pd.DataFrame, statement_type: str) -> pd.DataFrame:
    """
    Converts Excel sheet → normalized long format.
    Handles missing columns and empty sheets gracefully.
    """
    if df_raw is None or df_raw.empty:
        return pd.DataFrame()

    df_raw.columns = [str(c).strip() for c in df_raw.columns]

    if df_raw.shape[1] < 3:
        return pd.DataFrame()

    period_cols = [c for c in df_raw.columns[1:] if re.match(r"\d{4}", c)]
    if not period_cols:
        return pd.DataFrame(columns=["statement_type", "period", "account", "value"])

    try:
        melted = df_raw.melt(
            id_vars=df_raw.columns[0],
            value_vars=period_cols,
            var_name="period",
            value_name="value"
        )
        melted.rename(columns={df_raw.columns[0]: "account"}, inplace=True)
        melted["statement_type"] = statement_type
        melted = melted[["statement_type", "period", "account", "value"]]
        return melted
    except Exception as e:
        print(f"[Normalize] Melt failed: {e}")
        return pd.DataFrame()



