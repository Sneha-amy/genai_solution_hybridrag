#Initializing app
