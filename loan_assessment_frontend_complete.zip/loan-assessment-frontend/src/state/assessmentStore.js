
export const assessmentStore = {
  reports: [],
  addReport(r){ this.reports.push(r); }
};
