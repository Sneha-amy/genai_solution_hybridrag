
import { submitAssessment } from '../api/assessmentApi.js';
import { sessionStore } from '../state/sessionStore.js';
import { assessmentStore } from '../state/assessmentStore.js';

export function renderApplicantForm(container){
  container.innerHTML = `
    <div class="card">
      <h2>New Assessment</h2>
      <input id="a_id" placeholder="Applicant ID"><br>
      <input id="p_id" placeholder="Product ID"><br>
      <input id="a_amt" type="number" placeholder="Loan Amount"><br>
      <input id="a_ten" type="number" placeholder="Tenure (months)"><br>
      <textarea id="q" placeholder="Question"></textarea><br>
      <button id="submitBtn">Submit</button>
    </div>
  `;
  container.querySelector("#submitBtn").onclick = async ()=>{
    const payload = {
      session_id: sessionStore.sessionId,
      applicant_id: container.querySelector("#a_id").value,
      product_id: container.querySelector("#p_id").value,
      loan_amount_requested: Number(container.querySelector("#a_amt").value),
      tenure_months: Number(container.querySelector("#a_ten").value),
      free_text_questions: container.querySelector("#q").value
    };
    const r = await submitAssessment(payload);
    if(!sessionStore.sessionId) sessionStore.setSession(r.session_id);
    sessionStore.addApplicant(r.applicant_id);
    assessmentStore.addReport(r);
    document.dispatchEvent(new Event("resultsUpdated"));
  };
}
