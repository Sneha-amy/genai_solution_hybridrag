# graph/graph_builder.py

from langgraph.graph import StateGraph,END
from graph.state import PipelineState
from graph.nodes import (
    ingestion_node,
    rule_engine_node,
    ml_anomaly_node,
    merge_anomalies_node,
    compliance_node,
    recommendation_node,trend_analysis_node,
    materiality_node,
    severity_scoring_node,ml_explainability_node,narrative_explainability_node,recommendation_node,rule_explainability_node
)

def build_graph():
    """
    Build the full Phase-2 anomaly detection graph.
    Pipeline:
        ingestion → rule → ml → merge → compliance → recommend
    """
    
    graph = StateGraph(PipelineState)

    # ------------------------------------------
    # Register nodes
    # ------------------------------------------
    graph.add_node("ingestion", ingestion_node)
    graph.add_node("rule_engine", rule_engine_node)
    graph.add_node("ml_anomaly", ml_anomaly_node)
    graph.add_node("merge", merge_anomalies_node)
    graph.add_node("compliance", compliance_node)
    graph.add_node("recommendation", recommendation_node)
    graph.add_node("trend_analysis_node", trend_analysis_node)
    graph.add_node("materiality_node", materiality_node)
    graph.add_node("severity_scoring_node", severity_scoring_node)
    graph.add_node("ml_explainability_node", ml_explainability_node)
    graph.add_node("rule_explainability_node",rule_explainability_node)
    graph.add_node("narrative_explainability_node",narrative_explainability_node)




    # ------------------------------------------
    # Set entry point
    # ------------------------------------------
    graph.set_entry_point("ingestion")

    # ------------------------------------------
    # Define execution path
    # ------------------------------------------
    graph.add_edge("ingestion", "rule_engine")
    graph.add_edge("rule_engine", "ml_anomaly")
    graph.add_edge("ml_anomaly", "merge")
    graph.add_edge("merge", "trend_analysis_node")
    graph.add_edge("trend_analysis_node", "materiality_node")
    graph.add_edge("materiality_node", "severity_scoring_node")
    graph.add_edge("severity_scoring_node", "rule_explainability_node")
    graph.add_edge("rule_explainability_node", "ml_explainability_node")
    graph.add_edge("ml_explainability_node", "narrative_explainability_node")
    graph.add_edge("narrative_explainability_node","compliance")
    graph.add_edge("compliance", "recommendation")
    graph.add_edge("recommendation",END)

    # ------------------------------------------
    # Compile graph
    # ------------------------------------------
    return graph.compile()
