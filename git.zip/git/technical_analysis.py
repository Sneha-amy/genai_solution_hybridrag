import pandas as pd
import ta
from ta.trend import ADXIndicator, CCIIndicator, MACD, SMAIndicator, EMAIndicator
from ta.momentum import RSIIndicator, StochasticOscillator
from ta.volatility import BollingerBands, AverageTrueRange

class TechnicalAnalysis:
    """
    Engine to calculate technical indicators on a pandas DataFrame.
    Expects DataFrame with columns: ['open', 'high', 'low', 'close', 'volume']
    """
    
    @staticmethod
    def add_all_indicators(df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        
        # Ensure correct data types
        df['close'] = df['close'].astype(float)
        df['high'] = df['high'].astype(float)
        df['low'] = df['low'].astype(float)
        df['volume'] = df['volume'].astype(float)

        # 1. Trend Strength
        # ADX
        adx = ADXIndicator(df['high'], df['low'], df['close'], window=14)
        df['ADX'] = adx.adx()
        df['ADX_pos'] = adx.adx_pos()
        df['ADX_neg'] = adx.adx_neg()

        # MACD
        macd = MACD(df['close'])
        df['MACD'] = macd.macd()
        df['MACD_signal'] = macd.macd_signal()
        df['MACD_diff'] = macd.macd_diff()

        # 2. Momentum
        # RSI
        rsi = RSIIndicator(df['close'], window=14)
        df['RSI'] = rsi.rsi()

        # Stochastic
        stoch = StochasticOscillator(df['high'], df['low'], df['close'], window=14, smooth_window=3)
        df['Stoch_K'] = stoch.stoch()
        df['Stoch_D'] = stoch.stoch_signal()

        # 3. Volatility
        # Bollinger Bands
        bb = BollingerBands(df['close'], window=20, window_dev=2)
        df['BB_High'] = bb.bollinger_hband()
        df['BB_Low'] = bb.bollinger_lband()
        df['BB_Mid'] = bb.bollinger_mavg()
        df['BB_Width'] = bb.bollinger_wband()

        # ATR
        atr = AverageTrueRange(df['high'], df['low'], df['close'], window=14)
        df['ATR'] = atr.average_true_range()

        # 4. Volume
        # VWAP
        df['VWAP'] = (df['volume'] * (df['high'] + df['low'] + df['close']) / 3).cumsum() / df['volume'].cumsum()
        
        # OBV (On-Balance Volume)
        df['OBV'] = ta.volume.OnBalanceVolumeIndicator(df['close'], df['volume']).on_balance_volume()
        
        # RVOL (Relative Volume)
        # Ratio of current volume to 20-period SMA of volume
        df['Vol_SMA'] = df['volume'].rolling(window=20).mean()
        df['RVOL'] = df['volume'] / df['Vol_SMA']

        return df

    @staticmethod
    def analyze_trend(df: pd.DataFrame) -> dict:
        """
        Returns a simplified analysis of the latest candle.
        """
        if df.empty:
            return {}
            
        latest = df.iloc[-1]
        
        signal = {
            "trend": "NEUTRAL",
            "strength": "WEAK",
            "rsi_status": "NEUTRAL",
            "action": "HOLD"
        }
        
        # Trend Determination (Simple MA Crossover or MACD)
        if latest['MACD'] > latest['MACD_signal']:
            signal['trend'] = "BULLISH"
        elif latest['MACD'] < latest['MACD_signal']:
            signal['trend'] = "BEARISH"
            
        # Strength (ADX)
        if latest['ADX'] > 25:
            signal['strength'] = "STRONG"
        
        # RSI
        if latest['RSI'] > 70:
            signal['rsi_status'] = "OVERBOUGHT"
        elif latest['RSI'] < 30:
            signal['rsi_status'] = "OVERSOLD"
            
        return signal
