"""TODO: Paste the full implementation from ChatGPT conversation here."""
