#!/usr/bin/env python3
"""
Diagnostic script to analyze stock price distribution
"""

import time
import logging
from collections import defaultdict
from angel_one_api import login_angel_one
from TOKEN_MAP import TOKEN_MAP

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_current_price(obj, symbol, token):
    """Get current price for a single stock"""
    try:
        # Try LTP (Last Traded Price) first - more reliable for current prices
        try:
            ltp_data = obj.ltpData("NSE", symbol, token)
            if ltp_data and ltp_data.get('status') and ltp_data.get('data'):
                ltp = ltp_data['data'].get('ltp')
                if ltp:
                    return float(ltp)
        except Exception as ltp_error:
            logger.debug(f"LTP failed for {symbol}: {ltp_error}")
        
        # Fallback to historical data with adjusted parameters
        from datetime import datetime, timedelta
        
        # Use a wider date range
        to_date = datetime.now().strftime("%Y-%m-%d 15:30")
        from_date = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d 09:15")
        
        params = {
            "exchange": "NSE",
            "symboltoken": token,
            "interval": "ONE_DAY",
            "fromdate": from_date,
            "todate": to_date
        }
        
        hist_data = obj.getCandleData(params)
        
        if hist_data and isinstance(hist_data, dict):
            if 'Access denied' in str(hist_data) or hist_data.get('message') == 'Access denied':
                logger.warning(f"Access denied for {symbol}")
                return None
                
            if hist_data.get('status') and hist_data.get('data'):
                data = hist_data['data']
                if data and len(data) > 0:
                    latest = data[-1]
                    if len(latest) > 4:
                        price = float(latest[4])  # Close price
                        return price
        
        return None
        
    except Exception as e:
        logger.error(f"Error getting price for {symbol}: {e}")
        return None

def analyze_price_distribution():
    """Analyze the price distribution of all stocks"""
    logger.info("Starting price distribution analysis...")
    
    obj = login_angel_one()
    if not obj:
        logger.error("Failed to login to Angel One API")
        return
    
    price_ranges = {
        'under_10': [],
        '10_30': [],
        '30_100': [],
        '100_300': [],
        '300_500': [],
        '500_1000': [],
        'over_1000': [],
        'no_data': []
    }
    
    # Sample first 50 stocks for quick analysis
    sample_stocks = list(TOKEN_MAP.items())[:50]
    
    for i, (symbol, token) in enumerate(sample_stocks, 1):
        logger.info(f"Checking {i}/50: {symbol}")
        
        price = get_current_price(obj, symbol, token)
        
        if price is None:
            price_ranges['no_data'].append(symbol)
            logger.info(f"  {symbol}: No data")
        else:
            logger.info(f"  {symbol}: ₹{price:.2f}")
            
            if price < 10:
                price_ranges['under_10'].append((symbol, price))
            elif price < 30:
                price_ranges['10_30'].append((symbol, price))
            elif price < 100:
                price_ranges['30_100'].append((symbol, price))
            elif price < 300:
                price_ranges['100_300'].append((symbol, price))
            elif price < 500:
                price_ranges['300_500'].append((symbol, price))
            elif price < 1000:
                price_ranges['500_1000'].append((symbol, price))
            else:
                price_ranges['over_1000'].append((symbol, price))
        
        time.sleep(0.5)  # Rate limiting
    
    # Print analysis
    print(f"\n{'='*60}")
    print("PRICE DISTRIBUTION ANALYSIS (Sample of 50 stocks)")
    print(f"{'='*60}")
    
    for range_name, stocks in price_ranges.items():
        count = len(stocks)
        percentage = (count / len(sample_stocks)) * 100
        
        if range_name == 'no_data':
            print(f"{range_name.replace('_', ' ').title()}: {count} stocks ({percentage:.1f}%)")
        else:
            print(f"{range_name.replace('_', ' ').title()}: {count} stocks ({percentage:.1f}%)")
            if stocks and range_name != 'no_data':
                # Show a few examples
                examples = stocks[:3]
                for symbol, price in examples:
                    print(f"  - {symbol}: ₹{price:.2f}")
                if len(stocks) > 3:
                    print(f"  ... and {len(stocks)-3} more")
    
    print(f"\n{'='*60}")
    
    # Specifically check target range
    target_range_count = len(price_ranges['30_100']) + len(price_ranges['100_300'])
    print(f"Stocks in target range (₹30-₹300): {target_range_count}")
    
    if target_range_count > 0:
        print("Examples in target range:")
        for symbol, price in (price_ranges['30_100'] + price_ranges['100_300'])[:10]:
            print(f"  - {symbol}: ₹{price:.2f}")

if __name__ == "__main__":
    analyze_price_distribution()