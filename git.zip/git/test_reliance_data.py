"""
Test script to fetch historical data for RELIANCE stock from Angel One API
"""
from SmartApi import SmartConnect
import pyotp
from datetime import datetime, timedelta

# === CONFIG ===
API_KEY = "VKmmcehj"
CLIENT_CODE = "AAAL262999"
PASSWORD = "7382"
TOTP_SECRET = 'KH4X7EYYLUPRXFRIW6DDWZNOVU'

def login_angel_one():
    """Login to Angel One API"""
    try:
        obj = SmartConnect(api_key=API_KEY)
        totp_code = pyotp.TOTP(TOTP_SECRET).now()
        
        session = obj.generateSession(CLIENT_CODE, PASSWORD, totp_code)
        
        if session and session.get('status'):
            print("✓ Login successful")
            return obj
        else:
            print(f"✗ Login failed: {session}")
            return None
    except Exception as e:
        print(f"✗ Login error: {e}")
        return None

def fetch_reliance_data(obj):
    """Fetch historical data for RELIANCE"""
    try:
        # RELIANCE token for NSE
        symbol_token = "2885"  # RELIANCE NSE token
        
        # Date range: last 30 days
        to_date = datetime.now().strftime("%Y-%m-%d %H:%M")
        from_date = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d %H:%M")
        
        params = {
            "exchange": "NSE",
            "symboltoken": symbol_token,
            "interval": "ONE_DAY",
            "fromdate": from_date,
            "todate": to_date
        }
        
        print(f"\nFetching RELIANCE data from {from_date} to {to_date}...")
        
        hist_data = obj.getCandleData(params)
        
        if hist_data and hist_data.get('status'):
            data = hist_data.get('data', [])
            print(f"\n✓ Fetched {len(data)} candles")
            print("\nSample data (last 5 days):")
            print("-" * 80)
            print(f"{'Date':<20} {'Open':<10} {'High':<10} {'Low':<10} {'Close':<10} {'Volume':<15}")
            print("-" * 80)
            
            for candle in data[-5:]:
                date = candle[0]
                open_price = candle[1]
                high = candle[2]
                low = candle[3]
                close = candle[4]
                volume = candle[5]
                print(f"{date:<20} {open_price:<10} {high:<10} {low:<10} {close:<10} {volume:<15}")
            
            return data
        else:
            print(f"✗ Failed to fetch data: {hist_data}")
            return None
            
    except Exception as e:
        print(f"✗ Error fetching data: {e}")
        return None

if __name__ == "__main__":
    print("=" * 80)
    print("RELIANCE Historical Data Fetch Test")
    print("=" * 80)
    
    # Login
    obj = login_angel_one()
    
    if obj:
        # Fetch RELIANCE data
        data = fetch_reliance_data(obj)
        
        if data:
            print("\n" + "=" * 80)
            print("✓ TEST PASSED - Successfully fetched RELIANCE historical data")
            print("=" * 80)
        else:
            print("\n" + "=" * 80)
            print("✗ TEST FAILED - Could not fetch data")
            print("=" * 80)
    else:
        print("\n" + "=" * 80)
        print("✗ TEST FAILED - Could not login")
        print("=" * 80)
