
import { assessmentStore } from '../state/assessmentStore.js';
import { renderAnalysisCard } from './analysis-card.js';

export function renderAnalysisList(container){
  function refresh(){
    container.innerHTML = "";
    assessmentStore.reports.forEach(r=>{
      const card = document.createElement("div");
      renderAnalysisCard(card, r);
      container.appendChild(card);
    });
  }
  refresh();
  document.addEventListener("resultsUpdated", refresh);
}
