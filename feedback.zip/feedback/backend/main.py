from fastapi import FastAPI
from pydantic import BaseModel
from langchain_openai import ChatOpenAI
from pii_test import process_text_with_safety   # Uses safety.yaml + PII internally
import httpx
import os
from dotenv import load_dotenv, find_dotenv

load_dotenv(find_dotenv())

api_key = os.getenv("OPEN_AI_API_KEY")
app = FastAPI()
client = httpx.Client(verify=False)
llm = ChatOpenAI(
 base_url="https://genailab.tcs.in",
 model="azure_ai/genailab-maas-DeepSeek-V3-0324",
 api_key=api_key,
 http_client=client
)
# --------------------------
# Request Schema
# --------------------------
class ChatRequest(BaseModel):
    user_id: str = "guest"
    message: str


# --------------------------
# Safety + PII Sanitization
# --------------------------
@app.post("/chat")
async def chat(req: ChatRequest):

    # ------------------------------------------------------------------
    # STEP 1: Apply safety.yaml + PII redaction
    # ------------------------------------------------------------------
    safe = process_text_with_safety(req.message)

    # → If unsafe, BLOCK immediately (no llm call)
    if safe["status"] == "blocked":
        return {
            "reply": None,
            "sanitized_input": None,
            "pii_detected": [],
            "blocked_reason": safe["error"],
            "status": "blocked"
        }

    sanitized_input = safe["redacted"]

    # ------------------------------------------------------------------
    # STEP 2: Plain LLM call with sanitized text
    # ------------------------------------------------------------------
    llm_response = llm.invoke(sanitized_input)
    reply_text = llm_response.content

    # ------------------------------------------------------------------
    # STEP 3: Return final packaged result
    # ------------------------------------------------------------------
    return {
        "reply": reply_text,
        "sanitized_input": sanitized_input,
        "pii_detected": safe["pii_detected"],
        "status": "success"
    }
@app.get("/")
def home():
    return {"message": "Safety + PII API is running"}
