# graph/state.py
from typing import List, Dict, Any, Optional
from pydantic import BaseModel

class PipelineState(BaseModel):
    files: Optional[List[str]] = None
    metadata: Dict[str, Any] = {}

    df_normalized: Optional[Any] = None

    rule_anomalies: List[Dict[str, Any]] = []
    ml_anomalies: List[Dict[str, Any]] = []
    combined_anomalies: List[Dict[str, Any]] = []

    compliance_enriched: List[Dict[str, Any]] = []
    recommendations: List[Dict[str, Any]] = []
    trend_analysis: List[Dict[str, Any]] = []
    materiality_scores: List[Dict[str, Any]] = []
    anomaly_scores: List[Dict[str, Any]] = []

    errors: List[str] = []    # <── important for graceful recovery

    class Config:
        arbitrary_types_allowed = True
