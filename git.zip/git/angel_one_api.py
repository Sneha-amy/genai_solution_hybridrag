from SmartApi import SmartConnect
import pyotp
from datetime import datetime, timedelta
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Angel One credentials
API_KEY = "VKmmcehj"
CLIENT_CODE = "AAAL262999"
PASSWORD = "7382"
TOTP_SECRET = 'KH4X7EYYLUPRXFRIW6DDWZNOVU'

def login_angel_one():
    """Login to Angel One API and return SmartConnect object"""
    try:
        obj = SmartConnect(api_key=API_KEY)
        totp_code = pyotp.TOTP(TOTP_SECRET).now()
        session = obj.generateSession(CLIENT_CODE, PASSWORD, totp_code)
        
        if session and session.get('status'):
            logger.info("Angel One login successful")
            return obj
        else:
            logger.error(f"Angel One login failed: {session}")
            return None
    except Exception as e:
        logger.error(f"Angel One login error: {e}")
        return None

def fetch_stock_data(obj, symbol, token):
    """Fetch historical data for a stock and return OHLCV data with current metrics"""
    try:
        # Try LTP first for current price
        current_price = None
        try:
            ltp_data = obj.ltpData("NSE", symbol, token)
            if ltp_data and ltp_data.get('status') and ltp_data.get('data'):
                ltp = ltp_data['data'].get('ltp')
                if ltp:
                    current_price = float(ltp)
        except Exception:
            pass
        
        # Get historical data for OHLCV and fallback price
        to_date = datetime.now().strftime("%Y-%m-%d 15:30")
        from_date = (datetime.now() - timedelta(days=15)).strftime("%Y-%m-%d 09:15")
        
        params = {
            "exchange": "NSE",
            "symboltoken": token,
            "interval": "ONE_DAY",
            "fromdate": from_date,
            "todate": to_date
        }
        
        hist_data = obj.getCandleData(params)
        
        if not hist_data or not isinstance(hist_data, dict):
            raise ValueError(f"Invalid response for {symbol}")
        
        if 'Access denied' in str(hist_data) or hist_data.get('message') == 'Access denied':
            raise ValueError(f"Access denied for {symbol}")
        
        if not hist_data.get('status'):
            raise ValueError(f"API error for {symbol}: {hist_data.get('message', 'Unknown')}")
        
        data = hist_data.get('data')
        if not data or len(data) < 2:
            raise ValueError(f"Insufficient data for {symbol}: {len(data) if data else 0} records")
        
        # Convert to OHLCV format
        ohlcv_data = []
        for candle in data:
            if len(candle) >= 6:
                ohlcv_data.append({
                    'open': float(candle[1]),
                    'high': float(candle[2]), 
                    'low': float(candle[3]),
                    'close': float(candle[4]),
                    'volume': float(candle[5])
                })
        
        if len(ohlcv_data) < 2:
            raise ValueError(f"Insufficient valid OHLCV data for {symbol}")
        
        # Use current price from LTP or fallback to latest close
        latest = data[-1]
        previous = data[-2]
        
        if current_price is None:
            current_price = float(latest[4])
        
        prev_close = float(previous[4])
        
        if prev_close <= 0:
            raise ValueError(f"Invalid previous close price for {symbol}: {prev_close}")
        
        change_percent = ((current_price - prev_close) / prev_close) * 100
        
        return {
            "symbol": symbol,
            "price": current_price,
            "volume": float(latest[5]),
            "change": round(change_percent, 2),
            "ohlcv_data": ohlcv_data
        }
        
    except Exception as e:
        raise Exception(f"Error fetching {symbol}: {str(e)}")
