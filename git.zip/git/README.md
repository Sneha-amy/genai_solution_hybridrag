# Stock Market Analysis with LangGraph

## Architecture

**Backend (Python + LangGraph):**
- `stock_analysis_graph.py` - LangGraph workflow with 4 nodes
- `api_server.py` - Flask REST API

**Frontend (React + TypeScript):**
- `stock_dashboard.tsx` - Dashboard UI

## Setup

### Backend
```bash
pip install -r requirements.txt
```

### Frontend
```bash
npm install react react-dom lucide-react
```

## Run

### 1. Start Backend API
```bash
python api_server.py
```
Server runs on `http://localhost:5000`

### 2. Start Frontend
```bash
npm start
```

### 3. Access Dashboard
- Open browser to frontend URL
- Login with any username/password
- Click "Refresh Analysis" to run LangGraph

## LangGraph Flow

```
fetch_nse_data → technical_analysis → news_analysis → final_analysis
```

1. **fetch_nse_data**: Fetches NSE stocks, filters by volume/change
2. **technical_analysis**: RSI, MACD, moving averages
3. **news_analysis**: Sentiment analysis from news
4. **final_analysis**: Combines signals → BUY/HOLD/SKIP

## API Endpoint

**GET** `/api/analyze`

Returns:
```json
{
  "timestamp": "2024-01-01T12:00:00",
  "recommendations": [
    {
      "symbol": "RELIANCE",
      "price": 2450.50,
      "recommendation": "BUY",
      "finalScore": 75.5,
      "technicalSignal": "buy",
      "newsSentiment": "positive"
    }
  ]
}
```

## Visualization

Graph visualization saved as `stock_analysis_graph.png` when running the backend.
