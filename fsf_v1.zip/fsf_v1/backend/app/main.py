from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
import shutil
import os
from app.graph_runner import run_pipeline

app = FastAPI()

# Allow frontend calls
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # change to specific domain later
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "uploaded_files"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post("/analyze")
async def analyze_financials(
    files: List[UploadFile] = File(...),
    company: str = Form("Unknown Company"),
    period: str = Form("Unknown Period")
):
    """
    Trigger the Phase-2 financial anomaly detection pipeline.
    Accepts Excel/PDF uploads + company metadata.
    """

    saved_paths = []

    # ------------------------------------
    # Save uploaded files to disk
    # ------------------------------------
    for upload in files:
        file_path = os.path.join(UPLOAD_DIR, upload.filename)

        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(upload.file, buffer)

        saved_paths.append(file_path)

    # ------------------------------------
    # Run LangGraph Pipeline
    # ------------------------------------
    metadata = {"company": company, "period": period}
    result = run_pipeline(saved_paths, metadata)

    # ------------------------------------
    # Convert final results to clean JSON for frontend
    # ------------------------------------
    return {
        "company": company,
        "period": period,
        "errors": result.get("errors", []),
        "df_preview": str(result.get("df_normalized", "").head()) if result.get("df_normalized") is not None else None,
        "rule_anomalies": result.get("rule_anomalies", []),
        "ml_anomalies": result.get("ml_anomalies", []),
        "combined_anomalies": result.get("combined_anomalies", []),
        "compliance_enriched": result.get("compliance_enriched", []),
        "recommendations": result.get("recommendations", []),
    }
