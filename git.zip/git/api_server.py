from flask import Flask, jsonify
from flask_cors import CORS
from stock_analysis_graph import create_stock_analysis_graph, AgentState
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

graph = create_stock_analysis_graph()

@app.route('/api/analyze', methods=['GET'])
def analyze_stocks():
    logger.info("API /analyze endpoint called")
    
    initial_state: AgentState = {
        "raw_stocks": [],
        "filtered_stocks": [],
        "technical_analysis": {},
        "news_analysis": {},
        "final_recommendations": [],
        "strong_buy_recommendations": [],
        "timestamp": "",
        "error": None
    }
    
    result = graph.invoke(initial_state)
    
    recommendations = []
    for rec in result["final_recommendations"]:
        tech = result["technical_analysis"].get(rec["symbol"], {})
        news = result["news_analysis"].get(rec["symbol"], {})
        
        recommendations.append({
            "symbol": rec["symbol"],
            "name": f"{rec['symbol']} Ltd.",
            "price": rec["price"],
            "change": rec["change_percent"],
            "changePercent": rec["change_percent"],
            "recommendation": rec["action"],
            "finalScore": rec["final_score"],
            "technicalSignal": rec["technical_signal"],
            "newsSentiment": rec["news_sentiment"],
            "rsi": tech.get("rsi", 0),
            "macd": tech.get("macd", "neutral"),
            "llmAnalysis": rec["llm_analysis"],
            "volume": rec["volume"],
            "reason": rec["reason"]
        })
    
    return jsonify({
        "timestamp": result["timestamp"],
        "recommendations": recommendations,
        "strongBuyRecommendations": result["strong_buy_recommendations"],
        "filteredStocks": result["filtered_stocks"],
        "totalAnalyzed": len(result["filtered_stocks"]),
        "error": result.get("error")
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
