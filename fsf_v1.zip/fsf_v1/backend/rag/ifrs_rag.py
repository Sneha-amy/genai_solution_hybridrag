# rag/ifrs_rag.py
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import ChatOpenAI
import ollama
import os

class IFRSRAG:
    def __init__(self, persist_dir="rag/ifrs_store"):
        #self.embeddings = OpenAIEmbeddings(model="text-embedding-3-large")
        response = ollama.embed(model="mxbai-embed-large")
        self.embeddings = response["embeddings"]
        #self.db = Chroma(persist_directory=persist_dir,                 embedding_function=self.embeddings)
        self.db = Chroma(persist_directory=persist_dir,                 embedding_function=self.embeddings)
        #self.llm = ChatOpenAI(            model="gpt-4o-mini",            temperature=0.0        )
        

    def search(self, query, k=3):
        """Retrieve top-k IFRS references."""
        docs = self.db.similarity_search(query, k=k)
        return docs

    def summarize(self, query, docs):
        """Use the LLM to generate a concise IFRS compliance summary."""
        context = "\n\n".join([d.page_content for d in docs])

        prompt = f"""
        You are an IFRS compliance expert.

        Problem:
        {query}

        Relevant IFRS clauses:
        {context}

        Provide a 3–4 sentence explanation of:
        1. Which IFRS principles apply
        2. Why this anomaly violates or relates to them
        3. What a compliant financial statement should present
        """

        return self.llm.predict(prompt)
