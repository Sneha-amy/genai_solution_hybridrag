import { useState, useEffect } from 'react'
import './App.css'

interface Stock {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  recommendation: string;
  finalScore: number;
  technicalSignal: string;
  newsSentiment: string;
  rsi: number;
  macd: string;
  volume: number;
  llmAnalysis: string;
}

function App() {
  const [selectedStock, setSelectedStock] = useState<Stock | null>(null);
  const [isLeftPanelOpen, setIsLeftPanelOpen] = useState(true);
  const [logs, setLogs] = useState<Array<{id: number, timestamp: string, message: string, type: string}>>([]);
  const [stocks, setStocks] = useState<Stock[]>([]);
  const [filteredStocks, setFilteredStocks] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchStocks = async () => {
    setLoading(true);
    addLog('Fetching stock recommendations...', 'info');
    
    try {
      const response = await fetch('http://localhost:5000/api/analyze');
      const data = await response.json();
      
      if (data.error) {
        addLog(`Error: ${data.error}`, 'error');
      } else {
        setStocks(data.recommendations);
        setFilteredStocks(data.filteredStocks || []);
        addLog(`Loaded ${data.recommendations.length} stocks`, 'success');
        addLog(`Filtered ${data.filteredStocks?.length || 0} stocks`, 'info');
      }
    } catch (error: any) {
      addLog(`Failed: ${error.message}`, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Remove auto-fetch on component mount
    addLog('Click "Run Analysis" to start stock analysis', 'info');
  }, []);

  const addLog = (message: string, type = 'info') => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [{ id: Date.now(), timestamp, message, type }, ...prev].slice(0, 100));
  };

  const handleStockClick = (stock: Stock) => {
    setSelectedStock(stock);
    addLog(`Analyzing ${stock.symbol}...`, 'info');
    addLog(`Price: ₹${stock.price} | Change: ${stock.change}%`, 'info');
    addLog(`Technical Signal: ${stock.technicalSignal}`, 'success');
    addLog(`News Sentiment: ${stock.newsSentiment}`, 'success');
    addLog(`Final Score: ${stock.finalScore}`, 'success');
    addLog(`Recommendation: ${stock.recommendation}`, stock.recommendation === 'BUY' ? 'success' : 'warning');
  };

  return (
    <div style={{ display: 'flex', height: '100vh', background: '#111827', color: 'white' }}>
      {/* Left Panel */}
      <div style={{ width: isLeftPanelOpen ? '320px' : '0', transition: 'width 0.3s', background: '#1f2937', borderRight: '1px solid #374151', overflow: 'hidden' }}>
        <div style={{ padding: '16px', borderBottom: '1px solid #374151', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ fontSize: '18px', fontWeight: 'bold' }}>Stock Analysis</h2>
          <button 
            onClick={fetchStocks} 
            disabled={loading} 
            style={{ 
              padding: '8px 16px', 
              background: '#3b82f6', 
              border: 'none', 
              borderRadius: '4px',
              cursor: loading ? 'not-allowed' : 'pointer', 
              color: 'white',
              fontSize: '12px'
            }}
          >
            {loading ? 'Analyzing...' : 'Run Analysis'}
          </button>
        </div>
        
        {/* Filtered Stocks Section */}
        <div style={{ padding: '16px', borderBottom: '1px solid #374151' }}>
          <h3 style={{ fontSize: '14px', fontWeight: 'bold', marginBottom: '8px', color: '#9ca3af' }}>Filtered Stocks ({filteredStocks.length})</h3>
          <div style={{ maxHeight: '120px', overflowY: 'auto' }}>
            {filteredStocks.map((symbol) => (
              <div key={symbol} style={{ padding: '4px 8px', margin: '2px 0', background: '#374151', borderRadius: '4px', fontSize: '12px' }}>
                {symbol}
              </div>
            ))}
          </div>
        </div>
        
        {/* Recommendations Section */}
        <div style={{ padding: '16px 16px 8px 16px' }}>
          <h3 style={{ fontSize: '14px', fontWeight: 'bold', color: '#9ca3af' }}>Recommendations ({stocks.length})</h3>
        </div>
        <div style={{ overflowY: 'auto', height: 'calc(100vh - 280px)' }}>
          {stocks.map((stock) => (
            <div
              key={stock.symbol}
              onClick={() => handleStockClick(stock)}
              style={{
                padding: '16px',
                borderBottom: '1px solid #374151',
                cursor: 'pointer',
                background: selectedStock?.symbol === stock.symbol ? '#374151' : 'transparent',
                borderLeft: selectedStock?.symbol === stock.symbol ? '4px solid #3b82f6' : 'none'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <div>
                  <h3 style={{ fontWeight: 'bold' }}>{stock.symbol}</h3>
                  <p style={{ fontSize: '12px', color: '#9ca3af' }}>{stock.name}</p>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <p style={{ fontWeight: 'bold' }}>₹{stock.price}</p>
                  <p style={{ fontSize: '14px', color: stock.change >= 0 ? '#34d399' : '#f87171' }}>
                    {stock.change >= 0 ? '+' : ''}{stock.change}%
                  </p>
                </div>
              </div>
              <span style={{
                fontSize: '12px',
                padding: '4px 8px',
                borderRadius: '4px',
                background: stock.recommendation === 'BUY' ? '#059669' : stock.recommendation === 'HOLD' ? '#d97706' : '#6b7280'
              }}>
                {stock.recommendation}
              </span>
            </div>
          ))}
        </div>
      </div>

      <button
        onClick={() => setIsLeftPanelOpen(!isLeftPanelOpen)}
        style={{
          position: 'absolute',
          left: isLeftPanelOpen ? '320px' : '0',
          top: '50%',
          transform: 'translateY(-50%)',
          background: '#374151',
          border: 'none',
          padding: '8px',
          borderRadius: '0 8px 8px 0',
          cursor: 'pointer',
          color: 'white',
          zIndex: 10
        }}
      >
        {isLeftPanelOpen ? '◀' : '▶'}
      </button>

      {/* Center Panel */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '24px' }}>
        {selectedStock ? (
          <>
            <div style={{ marginBottom: '24px' }}>
              <h1 style={{ fontSize: '30px', fontWeight: 'bold', marginBottom: '8px' }}>{selectedStock.symbol}</h1>
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                <span style={{ fontSize: '36px', fontWeight: 'bold' }}>₹{selectedStock.price}</span>
                <span style={{ fontSize: '24px', color: selectedStock.change >= 0 ? '#34d399' : '#f87171' }}>
                  {selectedStock.change >= 0 ? '↑' : '↓'} {selectedStock.change >= 0 ? '+' : ''}{selectedStock.change}%
                </span>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '16px' }}>
              <div style={{ background: 'linear-gradient(to bottom right, #2563eb, #1e40af)', borderRadius: '8px', padding: '24px' }}>
                <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>Final Score</h3>
                <p style={{ fontSize: '30px', fontWeight: 'bold' }}>{selectedStock.finalScore}</p>
              </div>

              <div style={{ background: 'linear-gradient(to bottom right, #059669, #047857)', borderRadius: '8px', padding: '24px' }}>
                <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>Technical Signal</h3>
                <p style={{ fontSize: '24px', fontWeight: 'bold', textTransform: 'uppercase' }}>{selectedStock.technicalSignal}</p>
              </div>

              <div style={{ background: 'linear-gradient(to bottom right, #7c3aed, #6d28d9)', borderRadius: '8px', padding: '24px' }}>
                <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>News Sentiment</h3>
                <p style={{ fontSize: '24px', fontWeight: 'bold', textTransform: 'uppercase' }}>{selectedStock.newsSentiment}</p>
              </div>

              <div style={{ background: '#1f2937', border: '1px solid #374151', borderRadius: '8px', padding: '24px' }}>
                <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>RSI</h3>
                <p style={{ fontSize: '30px', fontWeight: 'bold' }}>{selectedStock.rsi}</p>
              </div>

              <div style={{ background: '#1f2937', border: '1px solid #374151', borderRadius: '8px', padding: '24px' }}>
                <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>MACD</h3>
                <p style={{ fontSize: '24px', fontWeight: 'bold', textTransform: 'uppercase' }}>{selectedStock.macd}</p>
              </div>

              <div style={{ background: '#1f2937', border: '1px solid #374151', borderRadius: '8px', padding: '24px' }}>
                <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>Volume</h3>
                <p style={{ fontSize: '24px', fontWeight: 'bold' }}>{(selectedStock.volume / 1000000).toFixed(2)}M</p>
              </div>

              <div style={{ background: 'linear-gradient(to bottom right, #ea580c, #c2410c)', borderRadius: '8px', padding: '24px', gridColumn: '1 / -1' }}>
                <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>Recommendation</h3>
                <p style={{ fontSize: '36px', fontWeight: 'bold' }}>{selectedStock.recommendation}</p>
              </div>

              <div style={{ background: '#1f2937', border: '1px solid #374151', borderRadius: '8px', padding: '24px', gridColumn: '1 / -1' }}>
                <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }}>🤖 AI Analysis</h3>
                <p style={{ fontSize: '14px', lineHeight: '1.5', color: '#d1d5db' }}>{selectedStock.llmAnalysis}</p>
              </div>
            </div>
          </>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: '#9ca3af' }}>
            <div style={{ textAlign: 'center' }}>
              <p style={{ fontSize: '20px' }}>Select a stock to view analysis</p>
            </div>
          </div>
        )}
      </div>

      {/* Right Panel - Console */}
      <div style={{ width: '384px', background: '#0a0a0a', borderLeft: '1px solid #374151', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '16px', borderBottom: '1px solid #374151' }}>
          <h2 style={{ fontSize: '18px', fontWeight: 'bold' }}>Analysis Console</h2>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', padding: '16px', fontFamily: 'monospace', fontSize: '12px' }}>
          {logs.length === 0 ? (
            <div style={{ color: '#6b7280', textAlign: 'center', marginTop: '32px' }}>
              <p>No logs yet</p>
            </div>
          ) : (
            logs.map((log) => (
              <div key={log.id} style={{ marginBottom: '8px', paddingBottom: '8px', borderBottom: '1px solid #1f2937' }}>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <span style={{ color: '#6b7280' }}>[{log.timestamp}]</span>
                  <span style={{
                    color: log.type === 'success' ? '#34d399' :
                           log.type === 'warning' ? '#fbbf24' :
                           log.type === 'error' ? '#f87171' : '#60a5fa'
                  }}>
                    {log.message}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
        <div style={{ padding: '16px', borderTop: '1px solid #374151' }}>
          <button
            onClick={() => setLogs([])}
            style={{ width: '100%', padding: '8px 16px', background: '#1f2937', border: 'none', borderRadius: '4px', color: 'white', cursor: 'pointer' }}
          >
            Clear Logs
          </button>
        </div>
      </div>
    </div>
  )
}

export default App
