from graph.graph_builder import build_graph

def run_pipeline(files: list, metadata: dict):
    graph = build_graph()
    initial_state = {
        "files": files,
        "metadata": metadata
    }
    result = graph.invoke(initial_state)
    return result
