
import { renderApplicantForm } from './applicant-form.js';
import { renderAnalysisList } from './analysis-list.js';

class AppRoot extends HTMLElement {
  connectedCallback(){
    this.innerHTML = `
      <h1>Loan Assessment Officer</h1>
      <div id="form"></div>
      <div id="results"></div>
    `;
    renderApplicantForm(document.getElementById("form"));
    renderAnalysisList(document.getElementById("results"));
  }
}
customElements.define("app-root", AppRoot);
